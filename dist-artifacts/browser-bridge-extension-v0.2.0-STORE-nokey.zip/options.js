"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULTS = {
    pageEvalEnabled: true,
    evalMask: true,
    confirmHighRiskClick: true,
    confirmPageEval: true,
    // confirm every page_eval (ADR-0008). Off = run unprompted.
    confirmTabClose: true,
    // confirm every tab_close. Off = close unprompted.
    warnPreciseSnapshot: true,
    confirmGraceMs: 6e4,
    clickToastTimeoutMs: 3e4,
    evalToastTimeoutMs: 45e3,
    disabledTools: [],
    // string[] of tool/op names that are blocked
    allowAllSites: false,
    cdpMode: false,
    // route ALL page ops through chrome.debugger (CDP). See ADR-0017.
    groupTabs: true
    // collect tab_open tabs into a "Browser Bridge" group. See ADR-0018.
  };

  // src/shared/ops.ts
  var TOOLS = [
    { op: "tab_list", desc: "\u5217\u51FA\u6240\u6709\u6807\u7B7E\u9875" },
    { op: "tab_focus", desc: "\u5207\u6362\u5230\u6307\u5B9A\u6807\u7B7E\u9875" },
    { op: "tab_open", desc: "\u6253\u5F00\u65B0\u6807\u7B7E\u9875(\u9700\u767D\u540D\u5355)" },
    { op: "tab_close", desc: "\u5173\u95ED\u6807\u7B7E\u9875(\u5E26\u786E\u8BA4)" },
    { op: "page_snapshot", desc: "\u5FEB\u7167\u9875\u9762\u53EF\u4EA4\u4E92\u5143\u7D20" },
    { op: "page_click", desc: "\u70B9\u51FB\u5143\u7D20" },
    { op: "page_fill", desc: "\u586B\u5199\u8868\u5355\u5B57\u6BB5" },
    { op: "page_text", desc: "\u8BFB\u53D6\u9875\u9762\u53EF\u89C1\u6587\u672C" },
    { op: "page_screenshot", desc: "\u622A\u53D6\u53EF\u89C6\u533A\u57DF" },
    { op: "page_scroll", desc: "\u6EDA\u52A8\u9875\u9762" },
    { op: "page_wait_for", desc: "\u7B49\u5F85\u6761\u4EF6\u6EE1\u8DB3" },
    { op: "page_eval", desc: "\u6267\u884C\u4EFB\u610F JS(\u9AD8\u5371)" },
    { op: "page_snapshot_precise", desc: "\u7CBE\u786E\u5FEB\u7167(\u8D70 debugger)" },
    { op: "cookie_get", desc: "\u8BFB\u53D6 Cookie(\u8131\u654F)" },
    { op: "storage_get", desc: "\u8BFB\u53D6 localStorage/sessionStorage(\u8131\u654F)" }
  ];
  var OP_NAMES = TOOLS.map((t) => t.op);

  // src/options.ts
  function $(id) {
    return document.getElementById(id);
  }
  async function loadSettings() {
    const keys = Object.keys(DEFAULTS);
    const stored = await chrome.storage.local.get(keys);
    return { ...DEFAULTS, ...stored };
  }
  async function saveSetting(key, value) {
    await chrome.storage.local.set({ [key]: value });
    flashToast("\u5DF2\u4FDD\u5B58");
  }
  var toastTimer = null;
  function flashToast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.add("show");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 1200);
  }
  function renderBool(key) {
    const input = $(key);
    const warn = $(`${key}-warn`);
    const card = $(`card-${key}`);
    input.addEventListener("change", (e) => {
      const checked = e.target.checked;
      if (warn) warn.style.display = checked ? "none" : "block";
      if (card) card.classList.toggle("danger", !!warn && !checked);
      saveSetting(key, checked);
    });
  }
  function wireAllowAllSites() {
    const input = $("allowAllSites");
    const warn = $("allowAllSites-warn");
    const card = $("card-allowAllSites");
    input.addEventListener("change", async (e) => {
      const target = e.target;
      const checked = target.checked;
      if (checked) {
        const granted = await chrome.permissions.request({
          origins: ["<all_urls>"]
        });
        if (!granted) {
          target.checked = false;
          flashToast("\u672A\u6388\u6743 <\u6240\u6709\u7F51\u5740>,\u5DF2\u4FDD\u6301\u9010\u7AD9\u70B9\u5BA1\u6279");
          return;
        }
      } else {
        await chrome.permissions.remove({ origins: ["<all_urls>"] });
      }
      if (warn) warn.style.display = checked ? "block" : "none";
      if (card) card.classList.toggle("danger", checked);
      await saveSetting("allowAllSites", checked);
      flashToast(checked ? "\u5DF2\u5141\u8BB8\u6240\u6709\u7AD9\u70B9" : "\u5DF2\u6062\u590D\u9010\u7AD9\u70B9\u5BA1\u6279");
    });
  }
  function renderNumber(key) {
    const input = $(key);
    input.addEventListener("change", (e) => {
      const v = parseInt(e.target.value, 10);
      if (Number.isNaN(v)) return;
      saveSetting(key, v);
    });
  }
  function renderToolsGrid(disabledTools) {
    const grid = $("tools-grid");
    const disabled = new Set(Array.isArray(disabledTools) ? disabledTools : []);
    grid.innerHTML = TOOLS.map((t) => {
      const checked = disabled.has(t.op) ? "" : "checked";
      return `<label class="tool"><input type="checkbox" data-op="${escapeAttr(t.op)}" ${checked} /><div><div class="name">${escapeHtml(t.op)}</div><div class="tdesc">${escapeHtml(t.desc)}</div></div></label>`;
    }).join("");
    grid.querySelectorAll("input[type=checkbox]").forEach((cb) => {
      cb.addEventListener("change", async () => {
        const all = grid.querySelectorAll("input[type=checkbox]");
        const next = [];
        all.forEach((c) => {
          if (!c.checked) next.push(c.getAttribute("data-op"));
        });
        await saveSetting("disabledTools", next);
      });
    });
  }
  async function refreshAllowlist() {
    const resp = await send({ type: "get_allowlist" });
    const list = resp?.list || [];
    const box = $("site-list");
    if (list.length === 0) {
      box.innerHTML = `<div class="empty">\u8FD8\u6CA1\u6709\u5141\u8BB8\u4EFB\u4F55\u7AD9\u70B9\u3002</div>`;
      return;
    }
    box.innerHTML = list.map(
      (g) => `<div class="item"><code>${escapeHtml(g)}</code><button class="danger" data-glob="${escapeAttr(g)}">\u79FB\u9664</button></div>`
    ).join("");
    box.querySelectorAll("button").forEach((b) => {
      b.onclick = async () => {
        const glob = b.getAttribute("data-glob");
        await send({ type: "remove_allow", glob });
        refreshAllowlist();
        flashToast("\u5DF2\u79FB\u9664");
      };
    });
  }
  function wireAddSite() {
    const input = $("new-site");
    const btn = $("add-site");
    async function add() {
      const v = input.value.trim();
      if (!v) return;
      if (!/^https?:\/\/[^/]+\//.test(v) && !/^https?:\/\/[^/]+$/.test(v)) {
        flashToast("\u683C\u5F0F\u5E94\u4E3A https://\u57DF\u540D/*");
        return;
      }
      let glob;
      try {
        const u = new URL(v);
        glob = `${u.protocol}//${u.host}/*`;
      } catch (_) {
        flashToast("URL \u89E3\u6790\u5931\u8D25");
        return;
      }
      const resp = await send({ type: "add_allow", glob });
      if (resp && resp.ok) {
        input.value = "";
        refreshAllowlist();
        flashToast("\u5DF2\u6DFB\u52A0");
      } else {
        flashToast(resp?.error || "\u6DFB\u52A0\u5931\u8D25");
      }
    }
    btn.onclick = add;
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") add();
    });
  }
  function send(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (resp) => resolve(resp));
    });
  }
  var HTML_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);
  }
  function escapeAttr(s) {
    return escapeHtml(s);
  }
  (async function init() {
    const s = await loadSettings();
    for (const key of [
      "pageEvalEnabled",
      "evalMask",
      "confirmHighRiskClick",
      "confirmPageEval",
      "confirmTabClose",
      "warnPreciseSnapshot",
      "groupTabs"
    ]) {
      const input = $(key);
      input.checked = s[key] !== false;
      const warn = $(`${key}-warn`);
      if (warn) warn.style.display = input.checked ? "none" : "block";
      const card = $(`card-${key}`);
      if (card && warn) card.classList.toggle("danger", !input.checked);
      renderBool(key);
    }
    {
      const input = $("cdpMode");
      const warn = $("cdpMode-warn");
      const card = $("card-cdpMode");
      const sync = (on) => {
        if (warn) warn.style.display = on ? "block" : "none";
        if (card) card.classList.toggle("danger", on);
      };
      input.checked = s.cdpMode === true;
      sync(input.checked);
      input.addEventListener("change", (e) => {
        const on = e.target.checked;
        sync(on);
        saveSetting("cdpMode", on);
      });
    }
    {
      const held = await chrome.permissions.contains({ origins: ["<all_urls>"] });
      const effective = s.allowAllSites === true && held;
      const input = $("allowAllSites");
      input.checked = effective;
      if (effective !== (s.allowAllSites === true)) {
        await chrome.storage.local.set({ allowAllSites: effective });
      }
      const warn = $("allowAllSites-warn");
      if (warn) warn.style.display = effective ? "block" : "none";
      const card = $("card-allowAllSites");
      if (card) card.classList.toggle("danger", effective);
      wireAllowAllSites();
    }
    for (const key of [
      "confirmGraceMs",
      "clickToastTimeoutMs",
      "evalToastTimeoutMs"
    ]) {
      const input = $(key);
      input.value = String(s[key]);
      renderNumber(key);
    }
    renderToolsGrid(s.disabledTools);
    await refreshAllowlist();
    wireAddSite();
  })();
})();
