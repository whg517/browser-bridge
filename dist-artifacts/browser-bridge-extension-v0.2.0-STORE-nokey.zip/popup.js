"use strict";
(() => {
  // src/popup.ts
  function $(id) {
    return document.getElementById(id);
  }
  async function refreshStatus() {
    const status = await send({ type: "get_status" });
    const dot = $("dot");
    dot.className = "dot " + (status?.nativeConnected ? "ok" : "bad");
    $("status-text").textContent = status?.nativeConnected ? "Connected to bridge" : "Not connected (is your MCP client running?)";
  }
  async function refreshList() {
    const resp = await send({ type: "get_allowlist" });
    const list = resp?.list || [];
    $("empty").style.display = list.length ? "none" : "block";
    $("list").innerHTML = list.map(
      (g) => `<div class="item"><code>${escapeHtml(g)}</code><button class="danger" data-glob="${escapeAttr(g)}">Revoke</button></div>`
    ).join("");
    document.querySelectorAll(".item button").forEach((b) => {
      b.onclick = async () => {
        const glob = b.getAttribute("data-glob");
        await send({ type: "remove_allow", glob });
        refreshList();
      };
    });
  }
  async function refreshPending() {
    const { pendingAllow } = await chrome.storage.local.get("pendingAllow");
    if (pendingAllow && pendingAllow.id && pendingAllow.glob) {
      const { id, glob } = pendingAllow;
      $("pending").style.display = "block";
      $("pending-glob").textContent = glob;
      $("allow").onclick = () => resolvePending(id, glob, true);
      $("deny").onclick = () => resolvePending(id, glob, false);
    } else {
      $("pending").style.display = "none";
    }
  }
  async function resolvePending(id, glob, allow) {
    if (allow) {
      const pattern = globToPattern(glob);
      try {
        const granted = await chrome.permissions.request({ origins: [pattern] });
        if (!granted) {
          await send({ type: "resolve_allow", id, allow: false });
          $("pending").style.display = "none";
          return;
        }
      } catch (e) {
        console.warn("[bb] permissions.request failed", e);
      }
    }
    await send({ type: "resolve_allow", id, allow });
    $("pending").style.display = "none";
    refreshList();
  }
  function globToPattern(glob) {
    return glob.endsWith("/*") ? glob : glob + "*";
  }
  function send(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (resp) => resolve(resp));
    });
  }
  var HTML_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);
  }
  function escapeAttr(s) {
    return escapeHtml(s);
  }
  $("open-settings").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
  refreshStatus();
  refreshList();
  refreshPending();
})();
