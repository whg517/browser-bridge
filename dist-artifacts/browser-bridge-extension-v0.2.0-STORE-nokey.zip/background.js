"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULTS = {
    pageEvalEnabled: true,
    evalMask: true,
    confirmHighRiskClick: true,
    confirmPageEval: true,
    // confirm every page_eval (ADR-0008). Off = run unprompted.
    confirmTabClose: true,
    // confirm every tab_close. Off = close unprompted.
    warnPreciseSnapshot: true,
    confirmGraceMs: 6e4,
    clickToastTimeoutMs: 3e4,
    evalToastTimeoutMs: 45e3,
    disabledTools: [],
    // string[] of tool/op names that are blocked
    allowAllSites: false,
    cdpMode: false,
    // route ALL page ops through chrome.debugger (CDP). See ADR-0017.
    groupTabs: true
    // collect tab_open tabs into a "Browser Bridge" group. See ADR-0018.
  };
  function getSetting(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get(key, (r) => {
        const v = r[key];
        resolve(v === void 0 ? DEFAULTS[key] : v);
      });
    });
  }

  // src/shared/allowlist.ts
  function originGlobOf(url) {
    try {
      const u = new URL(url);
      return `${u.protocol}//${u.host}/*`;
    } catch {
      return null;
    }
  }
  function hostFromOriginGlob(glob) {
    try {
      return new URL(glob.replace(/\*$/, "")).host.toLowerCase();
    } catch {
      return null;
    }
  }
  function normalizeCookieDomain(domain) {
    if (typeof domain !== "string") return null;
    let d = domain.trim().toLowerCase();
    if (!d || d.includes("://") || d.includes("/") || d.includes("*")) return null;
    while (d.startsWith(".")) d = d.slice(1);
    return d || null;
  }
  function matchesAny(glob, list) {
    return list.some((pattern) => simpleMatch(pattern, glob));
  }
  function simpleMatch(pattern, target) {
    if (pattern === target) return true;
    if (pattern.endsWith("/*")) {
      const base = pattern.slice(0, -2);
      return target === base || target.startsWith(base + "/");
    }
    if (pattern.endsWith("*")) {
      return target.startsWith(pattern.slice(0, -1));
    }
    return false;
  }
  function globToPermissionPattern(glob) {
    if (typeof glob !== "string" || !glob) return null;
    return glob.endsWith("/*") ? glob : glob + "*";
  }

  // src/background/allowlist-store.ts
  var STORAGE_KEY = "allowlist";
  async function getAllowlist() {
    const { [STORAGE_KEY]: list } = await chrome.storage.local.get(STORAGE_KEY);
    return Array.isArray(list) ? list : [];
  }
  async function setAllowlist(list) {
    await chrome.storage.local.set({ [STORAGE_KEY]: list });
  }
  async function ensureDomainAllowed(domain) {
    const host = normalizeCookieDomain(domain);
    if (!host) throw new Error(`invalid cookie domain: ${domain}`);
    if (await getSetting("allowAllSites") === true) return;
    const list = await getAllowlist();
    const allowed = list.some((glob) => hostFromOriginGlob(glob) === host);
    if (!allowed) {
      throw new Error(
        `cookie domain not allowed by user: ${domain}. Use a URL for the active allowlisted origin, or approve that exact host first.`
      );
    }
  }
  async function ensureAllowed(url) {
    const glob = originGlobOf(url);
    if (!glob) throw new Error(`cannot parse url: ${url}`);
    if (await getSetting("allowAllSites") === true) return;
    const list = await getAllowlist();
    if (matchesAny(glob, list)) return;
    const allowed = await promptUserForAllow(glob);
    if (!allowed) {
      throw new Error(`origin not allowed by user: ${glob}`);
    }
  }
  function promptUserForAllow(glob) {
    return new Promise((resolve) => {
      const reqId = `allow_${Date.now()}`;
      pendingAllowRequests.set(reqId, { glob, resolve });
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#d9534f" });
      chrome.storage.local.set({ pendingAllow: { id: reqId, glob } });
      setTimeout(() => {
        if (pendingAllowRequests.has(reqId)) {
          pendingAllowRequests.delete(reqId);
          chrome.storage.local.remove("pendingAllow");
          maybeClearBadge();
          resolve(false);
        }
      }, 6e4);
    });
  }
  var pendingAllowRequests = /* @__PURE__ */ new Map();
  function maybeClearBadge() {
    if (pendingAllowRequests.size === 0) {
      chrome.action.setBadgeText({ text: "" });
    }
  }
  async function resolvePendingAllow(id, allow) {
    const pending = pendingAllowRequests.get(id);
    if (!pending) return { ok: false, error: "no such pending request" };
    pendingAllowRequests.delete(id);
    chrome.storage.local.remove("pendingAllow");
    maybeClearBadge();
    if (allow) {
      const list = await getAllowlist();
      if (!list.includes(pending.glob)) list.push(pending.glob);
      await setAllowlist(list);
      pending.resolve(true);
    } else {
      pending.resolve(false);
    }
    return { ok: true };
  }
  async function addAllow(glob) {
    const list = await getAllowlist();
    if (!list.includes(glob)) list.push(glob);
    await setAllowlist(list);
    return list;
  }
  async function removeAllow(glob) {
    const list = await getAllowlist();
    const next = list.filter((g) => g !== glob);
    await setAllowlist(next);
    const pattern = globToPermissionPattern(glob);
    if (!pattern) return { list: next, permissionRemoved: false };
    return new Promise((resolve) => {
      chrome.permissions.remove({ origins: [pattern] }, (removed) => {
        resolve({
          list: next,
          permissionRemoved: Boolean(removed),
          permissionError: chrome.runtime.lastError?.message
        });
      });
    });
  }

  // src/shared/ops.ts
  var TOOLS = [
    { op: "tab_list", desc: "\u5217\u51FA\u6240\u6709\u6807\u7B7E\u9875" },
    { op: "tab_focus", desc: "\u5207\u6362\u5230\u6307\u5B9A\u6807\u7B7E\u9875" },
    { op: "tab_open", desc: "\u6253\u5F00\u65B0\u6807\u7B7E\u9875(\u9700\u767D\u540D\u5355)" },
    { op: "tab_close", desc: "\u5173\u95ED\u6807\u7B7E\u9875(\u5E26\u786E\u8BA4)" },
    { op: "page_snapshot", desc: "\u5FEB\u7167\u9875\u9762\u53EF\u4EA4\u4E92\u5143\u7D20" },
    { op: "page_click", desc: "\u70B9\u51FB\u5143\u7D20" },
    { op: "page_fill", desc: "\u586B\u5199\u8868\u5355\u5B57\u6BB5" },
    { op: "page_text", desc: "\u8BFB\u53D6\u9875\u9762\u53EF\u89C1\u6587\u672C" },
    { op: "page_screenshot", desc: "\u622A\u53D6\u53EF\u89C6\u533A\u57DF" },
    { op: "page_scroll", desc: "\u6EDA\u52A8\u9875\u9762" },
    { op: "page_wait_for", desc: "\u7B49\u5F85\u6761\u4EF6\u6EE1\u8DB3" },
    { op: "page_eval", desc: "\u6267\u884C\u4EFB\u610F JS(\u9AD8\u5371)" },
    { op: "page_snapshot_precise", desc: "\u7CBE\u786E\u5FEB\u7167(\u8D70 debugger)" },
    { op: "cookie_get", desc: "\u8BFB\u53D6 Cookie(\u8131\u654F)" },
    { op: "storage_get", desc: "\u8BFB\u53D6 localStorage/sessionStorage(\u8131\u654F)" }
  ];
  var OP_NAMES = TOOLS.map((t) => t.op);
  var TOOL_META = {
    tab_list: {
      risk: "low",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    tab_focus: {
      risk: "low",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    tab_open: {
      risk: "medium",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    tab_close: {
      risk: "high",
      scope: "tab",
      permission: "tabs",
      confirmation: "page-toast"
    },
    page_snapshot: {
      risk: "low",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_click: {
      risk: "high",
      scope: "page",
      permission: "scripting",
      confirmation: "high-risk"
    },
    page_fill: {
      risk: "high",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_text: {
      risk: "medium",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_screenshot: {
      risk: "medium",
      scope: "page",
      permission: "tabs",
      confirmation: "none"
    },
    page_scroll: {
      risk: "low",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_wait_for: {
      risk: "low",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_eval: {
      risk: "critical",
      scope: "page",
      permission: "scripting",
      confirmation: "every-call"
    },
    page_snapshot_precise: {
      risk: "medium",
      scope: "page",
      permission: "debugger",
      confirmation: "warn"
    },
    cookie_get: {
      risk: "high",
      scope: "tab",
      permission: "cookies",
      confirmation: "none"
    },
    storage_get: {
      risk: "high",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    }
  };

  // src/background/policy.ts
  var UNKNOWN_RISK = "critical";
  function confirmationFor(confirmation) {
    switch (confirmation) {
      case "none":
        return { requiresConfirmation: false, confirmationChannel: "none" };
      case "page-toast":
        return { requiresConfirmation: true, confirmationChannel: "page-toast" };
      default:
        return { requiresConfirmation: true, confirmationChannel: "extension-ui" };
    }
  }
  function decide(op, ctx) {
    const meta = TOOL_META[op];
    if (!meta) {
      return {
        allowed: false,
        risk: UNKNOWN_RISK,
        requiresConfirmation: true,
        confirmationChannel: "extension-ui",
        reason: "unknown tool"
      };
    }
    const { requiresConfirmation, confirmationChannel } = confirmationFor(meta.confirmation);
    if (ctx.disabledTools.includes(op)) {
      return {
        allowed: false,
        risk: meta.risk,
        requiresConfirmation,
        confirmationChannel,
        reason: "tool disabled in settings"
      };
    }
    return {
      allowed: true,
      risk: meta.risk,
      requiresConfirmation,
      confirmationChannel,
      reason: requiresConfirmation ? "allowed; requires confirmation" : "allowed"
    };
  }

  // src/background/tabs.ts
  async function resolveTargetTab(maybeTabId) {
    if (maybeTabId) {
      return await chrome.tabs.get(maybeTabId);
    }
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!active) throw new Error("no active tab");
    return active;
  }
  async function injectIfNeeded(tabId) {
    try {
      await chrome.tabs.sendMessage(tabId, { op: "ping" });
    } catch {
      await chrome.tabs.get(tabId);
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });
      try {
        await chrome.scripting.insertCSS({
          target: { tabId },
          files: ["toast.css"]
        });
      } catch (_) {
      }
    }
  }
  async function tabList() {
    const tabs = await chrome.tabs.query({});
    return tabs.map((t) => ({
      id: t.id,
      title: t.title,
      url: t.url,
      active: t.active,
      windowId: t.windowId,
      groupId: typeof t.groupId === "number" && t.groupId >= 0 ? t.groupId : void 0
    }));
  }
  async function tabFocus(tabId) {
    const t = await chrome.tabs.update(tabId, { active: true });
    if (!t) throw new Error(`tab ${tabId} not found`);
    await chrome.windows.update(t.windowId, { focused: true });
    return { focused: tabId };
  }
  var WORKSPACE_TITLE = "Browser Bridge";
  var WORKSPACE_COLOR = "blue";
  async function tabOpen(url) {
    await ensureAllowed(url);
    const t = await chrome.tabs.create({ url });
    let groupId;
    if (await getSetting("groupTabs") !== false && typeof t.id === "number") {
      groupId = await addToWorkspaceGroup(t.id, t.windowId);
    }
    return { opened: t.id, url, groupId };
  }
  async function addToWorkspaceGroup(tabId, windowId) {
    try {
      const groups = await chrome.tabGroups.query(windowId != null ? { windowId } : {});
      const existing = groups.find((g) => g.title === WORKSPACE_TITLE);
      if (existing) {
        await chrome.tabs.group({ tabIds: [tabId], groupId: existing.id });
        return existing.id;
      }
      const groupId = await chrome.tabs.group({ tabIds: [tabId] });
      await chrome.tabGroups.update(groupId, { title: WORKSPACE_TITLE, color: WORKSPACE_COLOR });
      return groupId;
    } catch (e) {
      console.warn("[bb] tab grouping failed:", e?.message || e);
      return void 0;
    }
  }
  async function tabClose(tabId) {
    const tab = await chrome.tabs.get(tabId);
    if (await getSetting("confirmTabClose") !== false) {
      await confirmTabClose(tab);
    }
    await chrome.tabs.remove(tabId);
    return { closed: tabId };
  }
  async function confirmTabClose(tab) {
    if (!tab || !tab.id) throw new Error("tab not found");
    if (!tab.url || !/^https?:\/\//i.test(tab.url)) {
      throw new Error(
        "tab_close can only close http(s) tabs because the close confirmation must be shown in the page"
      );
    }
    await ensureAllowed(tab.url);
    await injectIfNeeded(tab.id);
    const resp = await chrome.tabs.sendMessage(tab.id, {
      op: "_confirm_toast",
      args: { message: `Close tab "${tab.title || tab.url}"?` }
    });
    if (resp && resp.__error) throw new Error(resp.__error);
    if (!resp || resp.approved !== true) {
      throw new Error("user denied tab_close");
    }
  }

  // src/background/cdp/session.ts
  var NON_DEBUGGABLE = [
    /^chrome:\/\//i,
    /^chrome-extension:\/\//i,
    /^https:\/\/chrome\.google\.com\/webstore/i,
    /^view-source:/i,
    /^about:/i,
    /^edge:\/\//i
  ];
  function isDebuggable(url) {
    if (!url) return false;
    return !NON_DEBUGGABLE.some((re) => re.test(url));
  }
  function dbgAttach(tabId) {
    return new Promise((resolve, reject) => {
      chrome.debugger.attach({ tabId }, "1.3", () => {
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else resolve();
      });
    });
  }
  function dbgDetach(tabId) {
    return new Promise((resolve) => {
      chrome.debugger.detach({ tabId }, () => resolve());
    });
  }
  function dbgSend(tabId, method, params = {}) {
    return new Promise((resolve, reject) => {
      chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else resolve(result);
      });
    });
  }
  function buildEvaluateExpression(fn, args = []) {
    return `(${fn.toString()}).apply(undefined, ${JSON.stringify(args)})`;
  }
  function evalExceptionMessage(details) {
    const desc = details.exception?.description;
    if (desc) return desc.split("\n")[0];
    return details.text || "evaluation failed";
  }
  var CdpSession = class {
    tabId;
    attached = false;
    attaching = null;
    constructor(tabId) {
      this.tabId = tabId;
    }
    get isAttached() {
      return this.attached;
    }
    // Attach the debugger to this tab. Idempotent: a no-op if already attached.
    // The banner ("Started debugging this browser") stays up until detach — by
    // design in CDP mode (ADR-0017), the registry keeps sessions attached.
    async attach() {
      if (this.attached) return;
      if (!this.attaching) {
        this.attaching = this.doAttach().finally(() => {
          this.attaching = null;
        });
      }
      return this.attaching;
    }
    async doAttach() {
      try {
        await dbgAttach(this.tabId);
      } catch (e) {
        const msg = String(e.message || e);
        if (/another debugger/i.test(msg)) {
          throw new Error("\u8BE5\u6807\u7B7E\u9875\u5DF2\u6253\u5F00 DevTools,CDP \u6A21\u5F0F\u65E0\u6CD5\u9644\u52A0\u3002\u8BF7\u5173\u95ED DevTools \u540E\u91CD\u8BD5\u3002", {
            cause: e
          });
        }
        throw e;
      }
      this.attached = true;
    }
    async detach() {
      if (!this.attached) return;
      this.attached = false;
      await dbgDetach(this.tabId);
    }
    // Mark the session as detached WITHOUT calling chrome.debugger.detach — for
    // the case where Chrome already detached us (onDetach event).
    markDetached() {
      this.attached = false;
    }
    send(method, params = {}) {
      return dbgSend(this.tabId, method, params);
    }
    // Evaluate a page function (or raw expression) in the page's MAIN world.
    // returnByValue serializes the result to JSON. `awaitPromise` resolves a
    // returned promise before serializing (needed for wait_for / toasts).
    // Throws on an uncaught page exception.
    async evaluate(fnOrExpr, args = [], opts = {}) {
      const expression = typeof fnOrExpr === "function" ? buildEvaluateExpression(fnOrExpr, args) : fnOrExpr;
      const res = await this.send("Runtime.evaluate", {
        expression,
        returnByValue: true,
        awaitPromise: opts.awaitPromise ?? false,
        userGesture: true
      });
      if (res.exceptionDetails) {
        throw new Error(evalExceptionMessage(res.exceptionDetails));
      }
      return res.result?.value;
    }
    // Runtime.evaluate that returns the raw response (result + exceptionDetails)
    // so callers can map a page exception to structured data (page_eval).
    rawEvaluate(expression, opts = {}) {
      return this.send("Runtime.evaluate", {
        expression,
        returnByValue: true,
        awaitPromise: opts.awaitPromise ?? false,
        userGesture: true
      });
    }
    // Screenshot the viewport via CDP (preferred over a page-fn). Returns the
    // base64 PNG payload without the data: URL prefix, matching the content path.
    async screenshot() {
      const res = await this.send("Page.captureScreenshot", {
        format: "png"
      });
      return { image: res.data ?? "", mimeType: "image/png" };
    }
  };

  // src/background/cdp/registry.ts
  var CdpSessionRegistry = class {
    sessions = /* @__PURE__ */ new Map();
    // Get (creating + attaching lazily) the session for a tab. attach() is
    // idempotent, so this is cheap on the hot path.
    async get(tabId) {
      let session = this.sessions.get(tabId);
      if (!session) {
        session = new CdpSession(tabId);
        this.sessions.set(tabId, session);
      }
      try {
        await session.attach();
      } catch (e) {
        if (!session.isAttached) this.sessions.delete(tabId);
        throw e;
      }
      return session;
    }
    // Explicit teardown: detach and forget. Safe to call for an unknown tab.
    async teardown(tabId) {
      const session = this.sessions.get(tabId);
      if (!session) return;
      this.sessions.delete(tabId);
      await session.detach();
    }
    async teardownAll() {
      const sessions = [...this.sessions.values()];
      this.sessions.clear();
      await Promise.all(sessions.map((s) => s.detach()));
    }
    // Chrome already detached us (onDetach) — drop the session WITHOUT issuing a
    // redundant detach command.
    handleExternalDetach(tabId) {
      const session = this.sessions.get(tabId);
      if (!session) return;
      session.markDetached();
      this.sessions.delete(tabId);
    }
    // Whether a persistent session is currently held for this tab (no attach, no
    // side effect). Used by precise.ts to avoid a second, conflicting attach when
    // CDP mode already holds the tab.
    hasSession(tabId) {
      return this.sessions.has(tabId);
    }
    // For diagnostics / tests.
    get size() {
      return this.sessions.size;
    }
  };
  var cdpRegistry = new CdpSessionRegistry();
  var listenersInstalled = false;
  function installCdpLifecycleListeners() {
    if (listenersInstalled) return;
    listenersInstalled = true;
    chrome.tabs.onRemoved.addListener((tabId) => {
      void cdpRegistry.teardown(tabId);
    });
    chrome.debugger.onDetach.addListener((source) => {
      if (typeof source.tabId === "number") cdpRegistry.handleExternalDetach(source.tabId);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const change = changes.cdpMode;
      if (change && change.newValue === false) void cdpRegistry.teardownAll();
    });
  }

  // src/background/precise.ts
  var PRECISE_INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "checkbox",
    "radio",
    "textbox",
    "searchbox",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "combobox",
    "listbox",
    "option",
    "switch",
    "treeitem",
    "menuItem",
    "spinButton",
    "slider"
  ]);
  function axValue(v) {
    if (v && typeof v === "object" && "value" in v) return v.value;
    return v;
  }
  async function snapshotPrecise(maybeTabId, _args) {
    const tab = await resolveTargetTab(maybeTabId);
    await ensureAllowed(tab.url);
    if (!isDebuggable(tab.url)) {
      throw new Error(
        `page_snapshot_precise cannot debug this page (URL scheme not allowed): ${truncateUrl(tab.url)}`
      );
    }
    const warnPrecise = await getSetting("warnPreciseSnapshot");
    await injectIfNeeded(tab.id);
    let proceed = true;
    if (warnPrecise) {
      proceed = await chrome.tabs.sendMessage(tab.id, {
        op: "_info_toast",
        args: {
          message: "\u5373\u5C06\u7CBE\u786E\u626B\u63CF\u9875\u9762 \u2014 Chrome \u9876\u90E8\u4F1A\u663E\u793A\u300E\u8C03\u8BD5\u4E2D\u300F\u6A2A\u5E45,\u626B\u63CF\u540E\u81EA\u52A8\u6D88\u5931(\u7EA6 1 \u79D2)\u3002"
        }
      }).catch(
        () => true
        /* content script missing → proceed anyway */
      );
    }
    if (proceed === false || proceed && proceed.__cancelled) {
      return { cancelled: true };
    }
    if (proceed && proceed.__error) {
      console.warn("[bb] info toast failed:", proceed.__error);
    }
    const reusingAttach = cdpRegistry.hasSession(tab.id);
    if (!reusingAttach) {
      try {
        await dbgAttach(tab.id);
      } catch (e) {
        const msg = String(e.message || e);
        if (/another debugger/i.test(msg)) {
          throw new Error(
            "\u8BE5\u6807\u7B7E\u9875\u5DF2\u6253\u5F00 DevTools,page_snapshot_precise \u65E0\u6CD5\u9644\u52A0\u3002\u8BF7\u5173\u95ED DevTools \u540E\u91CD\u8BD5\u3002",
            { cause: e }
          );
        }
        throw e;
      }
    }
    try {
      const tree = await dbgSend(tab.id, "Accessibility.getFullAXTree", {});
      const nodes = tree.nodes ?? [];
      const candidates = nodes.filter((n) => {
        if (n.ignored) return false;
        if (!n.backendDOMNodeId) return false;
        const role = axValue(n.role);
        if (!role) return false;
        if (!PRECISE_INTERACTIVE_ROLES.has(role)) return false;
        return true;
      });
      const out = [];
      let idx = 0;
      for (const n of candidates) {
        idx += 1;
        const ref = `p${idx}`;
        let descriptor;
        try {
          const resolved = await dbgSend(tab.id, "DOM.resolveNode", {
            backendNodeId: n.backendDOMNodeId
          });
          const objectId = resolved.object?.objectId;
          if (!objectId) continue;
          const callRes = await dbgSend(tab.id, "Runtime.callFunctionOn", {
            objectId,
            functionDeclaration: "function(ref) {  this.setAttribute('data-zcb-ref', ref);  var id = this.id ? '#' + this.id : '';  var tag = (this.tagName || '').toLowerCase();  return { tag: tag, id: id, name: this.getAttribute('name') || '',     value: (this.value !== undefined ? String(this.value).slice(0,60) : undefined) };}",
            arguments: [{ value: ref }],
            returnByValue: true
          });
          descriptor = callRes.result?.value ?? {};
        } catch (e) {
          console.warn("[bb] precise: skip node", ref, e.message);
          continue;
        }
        out.push({
          ref,
          role: axValue(n.role),
          name: truncateAx(axValue(n.name)),
          selector: descriptor.tag ? descriptor.tag + descriptor.id : void 0,
          value: descriptor.value
        });
      }
      return {
        refCount: out.length,
        nodes: out,
        url: tab.url,
        title: tab.title,
        precise: true
      };
    } finally {
      if (!reusingAttach) await dbgDetach(tab.id);
    }
  }
  function truncateUrl(u) {
    return (u || "").slice(0, 80);
  }
  function truncateAx(s) {
    if (typeof s !== "string") return s;
    return s.length > 120 ? s.slice(0, 120) + "\u2026" : s;
  }

  // src/shared/masking.ts
  var SENSITIVE_KEY = /(token|cookie|password|passwd|secret|api[_-]?key|auth|cred|session)/i;
  function maskPatterns(s) {
    let out = s;
    out = out.replace(/ey[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g, "\u2022\u2022\u2022\u2022[jwt]");
    out = out.replace(/\b[a-fA-F0-9]{32,}\b/g, "\u2022\u2022\u2022\u2022[hex]");
    out = out.replace(/\b\d{12,}\b/g, "\u2022\u2022\u2022\u2022[num]");
    out = out.replace(
      /(?:bearer|token|password|secret|api[_-]?key)\s*[:=]\s*\S+/gi,
      "\u2022\u2022\u2022\u2022[redacted]"
    );
    return out;
  }
  function maskString(s) {
    if (s.length < 8) return s;
    const out = maskPatterns(s);
    if (SENSITIVE_KEY.test(s) && s.length >= 8 && !/\s/.test(s)) {
      return "\u2022\u2022\u2022\u2022[sensitive]";
    }
    return out;
  }
  function maskCookieValue(v) {
    if (typeof v !== "string") return v;
    if (v.length < 8) return v;
    return maskPatterns(v);
  }
  function maskNumber(n) {
    if (Number.isInteger(n) && Math.abs(n) >= 1e11) return "\u2022\u2022\u2022\u2022[num]";
    return n;
  }
  function maskKeyName(key) {
    return SENSITIVE_KEY.test(key) ? "\u2022\u2022\u2022\u2022" + key.slice(-2) : key;
  }
  function maskSensitive(value) {
    if (value === null || value === void 0) return value;
    const t = typeof value;
    if (t === "string") return maskString(value);
    if (t === "number") return maskNumber(value);
    if (t === "boolean") return value;
    if (Array.isArray(value)) return value.map(maskSensitive);
    if (t === "object") {
      const out = {};
      for (const k of Object.keys(value)) {
        out[maskKeyName(k)] = maskSensitive(value[k]);
      }
      return out;
    }
    return value;
  }

  // src/background/cookies.ts
  async function cookieGet(maybeTabId, args) {
    let { url } = args || {};
    const { domain, name } = args || {};
    if (!url && !domain) {
      const tab = await resolveTargetTab(maybeTabId);
      await ensureAllowed(tab.url);
      url = tab.url;
    } else if (url) {
      await ensureAllowed(url);
    }
    if (domain) {
      await ensureDomainAllowed(domain);
    }
    const filter = {};
    if (url) filter.url = url;
    if (domain) filter.domain = domain;
    if (name) filter.name = name;
    const cookies = await chrome.cookies.getAll(filter);
    if (!cookies || cookies.length === 0) {
      return {
        cookies: [],
        count: 0,
        hint: "No cookies matched. If you expected some, verify the host is in the allowlist (popup \u2192 Allowed sites)."
      };
    }
    const out = cookies.map((c) => ({
      name: c.name,
      value: maskCookieValue(c.value),
      domain: c.domain,
      path: c.path,
      httpOnly: c.httpOnly,
      secure: c.secure,
      sameSite: c.sameSite,
      session: c.session,
      expirationDate: c.expirationDate
    }));
    return { cookies: out, count: out.length };
  }

  // src/background/backends/content-script.ts
  var ContentScriptBackend = class {
    async run(op, args, tab) {
      await ensureAllowed(tab.url);
      await injectIfNeeded(tab.id);
      const resp = await chrome.tabs.sendMessage(tab.id, {
        op,
        args,
        tabId: tab.id
      });
      if (resp && resp.__error) throw new Error(resp.__error);
      return resp;
    }
  };

  // src/content/util.ts
  function truncate(s, n) {
    return s.length > n ? s.slice(0, n) + "\u2026" : s;
  }

  // src/background/cdp/page-fns.ts
  var REF_ATTR = "data-zcb-ref";
  function pageSnapshot(refAttr) {
    function truncate2(s, n) {
      return s.length > n ? s.slice(0, n) + "\u2026" : s;
    }
    const INTERACTIVE_TAGS = /* @__PURE__ */ new Set([
      "a",
      "button",
      "input",
      "textarea",
      "select",
      "summary",
      "details",
      "label",
      "option",
      "optgroup"
    ]);
    const INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
      "button",
      "link",
      "checkbox",
      "radio",
      "textbox",
      "searchbox",
      "menuitem",
      "menuitemcheckbox",
      "menuitemradio",
      "tab",
      "combobox",
      "listbox",
      "option",
      "switch",
      "treeitem"
    ]);
    function isInteractive(el) {
      const tag = el.tagName.toLowerCase();
      if (INTERACTIVE_TAGS.has(tag)) return true;
      const role = el.getAttribute("role");
      if (role && INTERACTIVE_ROLES.has(role)) return true;
      if (el.hasAttribute("onclick")) return true;
      if (el.tabIndex >= 0) return true;
      return false;
    }
    function roleOf(el) {
      const explicit = el.getAttribute("role");
      if (explicit) return explicit;
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute("type") || "").toLowerCase();
      if (tag === "a" && el.hasAttribute("href")) return "link";
      if (tag === "button") return "button";
      if (tag === "input") {
        if (type === "checkbox") return "checkbox";
        if (type === "radio") return "radio";
        if (type === "submit" || type === "button" || type === "reset") return "button";
        return "textbox";
      }
      if (tag === "textarea") return "textbox";
      if (tag === "select") return "listbox";
      if (tag === "summary") return "button";
      return tag;
    }
    function nameOf(el) {
      const labelledBy = el.getAttribute("aria-labelledby");
      if (labelledBy) {
        const parts = labelledBy.split(/\s+/).map((id) => document.getElementById(id)).filter((n) => n !== null).map((n) => n.innerText || n.textContent || "").join(" ").trim();
        if (parts) return truncate2(parts, 120);
      }
      const aria = el.getAttribute("aria-label");
      if (aria && aria.trim()) return truncate2(aria.trim(), 120);
      const labelFor = el.id ? document.querySelector(`label[for="${el.id}"]`) : null;
      if (labelFor) {
        const t = (labelFor.innerText || "").trim();
        if (t) return truncate2(t, 120);
      }
      const wrapping = el.closest("label");
      if (wrapping && wrapping !== labelFor) {
        const t = (wrapping.innerText || "").trim();
        if (t) return truncate2(t, 120);
      }
      if (el.title && el.title.trim()) return truncate2(el.title.trim(), 120);
      const txt = (el.innerText || el.textContent || "").trim();
      if (txt) return truncate2(txt, 120);
      const placeholder = el.getAttribute("placeholder");
      if (placeholder) return truncate2(placeholder, 120);
      const alt = el.getAttribute("alt");
      if (alt) return truncate2(alt, 120);
      return "";
    }
    function previewValue(el) {
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT") {
        const field = el;
        const v = field.value || "";
        if (field.type === "password") return v ? "\u2022\u2022\u2022\u2022\u2022\u2022" : "";
        return truncate2(v, 60);
      }
      return void 0;
    }
    function isVisible(el) {
      if (!el || !el.getClientRects) return false;
      const rects = el.getClientRects();
      if (rects.length === 0) return false;
      const style = getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden") return false;
      if (parseFloat(style.opacity) === 0) return false;
      let cur = el;
      while (cur && cur.nodeType === 1) {
        if (cur.getAttribute("aria-hidden") === "true") return false;
        cur = cur.parentElement;
      }
      return true;
    }
    function cssSelectorOf(el) {
      const parts = [];
      let cur = el;
      while (cur && cur.nodeType === 1 && cur !== document.body) {
        let part = cur.tagName.toLowerCase();
        if (cur.id) {
          part += `#${cur.id}`;
          parts.unshift(part);
          break;
        }
        const parent = cur.parentElement;
        if (parent) {
          const tag = cur.tagName;
          const siblings = Array.from(parent.children).filter((c) => c.tagName === tag);
          if (siblings.length > 1) {
            const idx = siblings.indexOf(cur) + 1;
            part += `:nth-of-type(${idx})`;
          }
        }
        parts.unshift(part);
        cur = cur.parentElement;
      }
      return parts.join(" > ");
    }
    let refCounter = 0;
    function assignRef(el) {
      let ref = el.getAttribute(refAttr);
      if (ref) {
        const reused = parseInt(ref.slice(1), 10);
        if (!Number.isNaN(reused) && reused > refCounter) refCounter = reused;
      } else {
        refCounter += 1;
        ref = `e${refCounter}`;
        el.setAttribute(refAttr, ref);
      }
      return ref;
    }
    const out = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (el) => isInteractive(el) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
    });
    let node;
    while (node = walker.nextNode()) {
      const el = node;
      if (!isVisible(el)) continue;
      const ref = assignRef(el);
      out.push({
        ref,
        role: roleOf(el),
        name: nameOf(el),
        selector: cssSelectorOf(el),
        value: previewValue(el)
      });
    }
    return { refCount: out.length, nodes: out, url: location.href, title: document.title };
  }
  function pageText() {
    function truncate2(s, n) {
      return s.length > n ? s.slice(0, n) + "\u2026" : s;
    }
    const cloneSrc = document.body.cloneNode(true);
    cloneSrc.querySelectorAll("input[type=password]").forEach((i) => i.value = "\u2022\u2022\u2022\u2022\u2022\u2022");
    const txt = (cloneSrc.innerText || "").replace(/\b\d{12,19}\b/g, "\u2022\u2022\u2022\u2022\u2022\u2022");
    return { text: truncate2(txt, 2e4), url: location.href };
  }
  function pageScroll(args) {
    if (typeof args.pixels === "number") {
      window.scrollBy(0, args.pixels);
    } else if (args.direction) {
      const dh = window.innerHeight * 0.9;
      switch (args.direction) {
        case "down":
          window.scrollBy(0, dh);
          break;
        case "up":
          window.scrollBy(0, -dh);
          break;
        case "top":
          window.scrollTo(0, 0);
          break;
        case "bottom":
          window.scrollTo(0, document.body.scrollHeight);
          break;
      }
    } else {
      throw new Error("scroll needs `direction` or `pixels`");
    }
    return { scrollY: window.scrollY, scrollX: window.scrollX };
  }
  function pageWaitFor(args) {
    const timeoutMs = args.timeoutMs ?? 3e4;
    const start = Date.now();
    return new Promise((resolve, reject) => {
      let done = false;
      const onLoad = () => {
        if (args.nav) {
          finish(resolve, {
            matched: true,
            nav: true,
            url: location.href,
            readyState: document.readyState
          });
        }
      };
      const finish = (fn, value) => {
        if (done) return;
        done = true;
        window.removeEventListener("load", onLoad, true);
        fn(value);
      };
      if (args.nav) {
        if (document.readyState === "complete") {
          return finish(resolve, {
            matched: true,
            nav: true,
            url: location.href,
            readyState: document.readyState
          });
        }
        window.addEventListener("load", onLoad, true);
      }
      const tick = () => {
        if (done) return;
        if (args.selector) {
          if (document.querySelector(args.selector)) {
            return finish(resolve, { matched: true, selector: args.selector });
          }
        }
        if (args.text) {
          if ((document.body.innerText || "").includes(args.text)) {
            return finish(resolve, { matched: true, text: args.text });
          }
        }
        if (Date.now() - start > timeoutMs) {
          return finish(reject, new Error(`wait_for timed out after ${timeoutMs}ms`));
        }
        setTimeout(tick, 150);
      };
      tick();
    });
  }
  function readStorage(args) {
    const type = args.type === "session" ? "session" : "local";
    const key = args.key;
    let store;
    try {
      store = type === "session" ? window.sessionStorage : window.localStorage;
    } catch (e) {
      throw new Error(`storage unavailable: ${e instanceof Error ? e.message : String(e)}`, {
        cause: e
      });
    }
    if (key !== void 0 && key !== null && key !== "") {
      const raw = store.getItem(key);
      if (raw === null) return { key, found: false };
      return { key, found: true, value: raw };
    }
    const entries = {};
    let count = 0;
    const MAX = 500;
    for (let i = 0; i < store.length && count < MAX; i++) {
      const k = store.key(i);
      if (k === null) continue;
      try {
        entries[k] = store.getItem(k) || "";
      } catch {
        entries[k] = "[unreadable]";
      }
      count++;
    }
    const truncated = store.length > MAX;
    return { type, entries, count, truncated, totalKeys: store.length };
  }
  function probeClickTarget(refAttr, args) {
    function truncate2(s, n) {
      return s.length > n ? s.slice(0, n) + "\u2026" : s;
    }
    function resolveTarget() {
      if (args.ref) {
        const el2 = document.querySelector(`[${refAttr}="${args.ref}"]`);
        if (!el2) throw new Error(`ref not found: ${args.ref} \u2014 call page_snapshot again`);
        return el2;
      }
      if (args.selector) {
        const el2 = document.querySelector(args.selector);
        if (!el2) throw new Error(`selector matched nothing: ${args.selector}`);
        return el2;
      }
      throw new Error("click/fill needs `ref` or `selector`");
    }
    function roleOf(el2) {
      const explicit = el2.getAttribute("role");
      if (explicit) return explicit;
      const tag = el2.tagName.toLowerCase();
      const type = (el2.getAttribute("type") || "").toLowerCase();
      if (tag === "a" && el2.hasAttribute("href")) return "link";
      if (tag === "button") return "button";
      if (tag === "input") {
        if (type === "checkbox") return "checkbox";
        if (type === "radio") return "radio";
        if (type === "submit" || type === "button" || type === "reset") return "button";
        return "textbox";
      }
      if (tag === "textarea") return "textbox";
      if (tag === "select") return "listbox";
      if (tag === "summary") return "button";
      return tag;
    }
    function nameOf(el2) {
      const aria = el2.getAttribute("aria-label");
      if (aria && aria.trim()) return truncate2(aria.trim(), 120);
      const labelFor = el2.id ? document.querySelector(`label[for="${el2.id}"]`) : null;
      if (labelFor) {
        const t = (labelFor.innerText || "").trim();
        if (t) return truncate2(t, 120);
      }
      if (el2.title && el2.title.trim()) return truncate2(el2.title.trim(), 120);
      const txt = (el2.innerText || el2.textContent || "").trim();
      if (txt) return truncate2(txt, 120);
      const placeholder = el2.getAttribute("placeholder");
      if (placeholder) return truncate2(placeholder, 120);
      return "";
    }
    const el = resolveTarget();
    return {
      tagName: el.tagName,
      role: roleOf(el),
      type: (el.getAttribute("type") || "").toLowerCase(),
      hasHref: el.tagName === "A" && el.hasAttribute("href"),
      name: nameOf(el)
    };
  }
  function doClick(refAttr, args) {
    function resolveTarget() {
      if (args.ref) {
        const el2 = document.querySelector(`[${refAttr}="${args.ref}"]`);
        if (!el2) throw new Error(`ref not found: ${args.ref} \u2014 call page_snapshot again`);
        return el2;
      }
      if (args.selector) {
        const el2 = document.querySelector(args.selector);
        if (!el2) throw new Error(`selector matched nothing: ${args.selector}`);
        return el2;
      }
      throw new Error("click/fill needs `ref` or `selector`");
    }
    function roleOf(el2) {
      const explicit = el2.getAttribute("role");
      if (explicit) return explicit;
      const tag = el2.tagName.toLowerCase();
      const type = (el2.getAttribute("type") || "").toLowerCase();
      if (tag === "a" && el2.hasAttribute("href")) return "link";
      if (tag === "button") return "button";
      if (tag === "input") {
        if (type === "checkbox") return "checkbox";
        if (type === "radio") return "radio";
        if (type === "submit" || type === "button" || type === "reset") return "button";
        return "textbox";
      }
      if (tag === "textarea") return "textbox";
      if (tag === "select") return "listbox";
      if (tag === "summary") return "button";
      return tag;
    }
    const el = resolveTarget();
    el.scrollIntoView({ block: "center" });
    el.focus?.();
    el.click();
    return { clicked: args.ref || args.selector, role: roleOf(el) };
  }
  function doFill(refAttr, args) {
    function resolveTarget() {
      if (args.ref) {
        const el2 = document.querySelector(`[${refAttr}="${args.ref}"]`);
        if (!el2) throw new Error(`ref not found: ${args.ref} \u2014 call page_snapshot again`);
        return el2;
      }
      if (args.selector) {
        const el2 = document.querySelector(args.selector);
        if (!el2) throw new Error(`selector matched nothing: ${args.selector}`);
        return el2;
      }
      throw new Error("click/fill needs `ref` or `selector`");
    }
    const el = resolveTarget();
    const value = args.value ?? "";
    el.focus?.();
    const field = el;
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) {
      setter.call(el, value);
    } else {
      field.value = value;
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return { filled: args.ref || args.selector };
  }
  function confirmToast(question, timeoutMs) {
    return new Promise((resolve) => {
      const host = document.createElement("div");
      host.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;display:flex;flex-direction:column;gap:8px;";
      const card = document.createElement("div");
      card.style.cssText = "box-sizing:border-box;pointer-events:auto;background:#fffbfb;color:#1f2937;border:1.5px solid #dc2626;border-left:4px solid #dc2626;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.16);padding:14px 16px;width:360px;font-family:-apple-system,system-ui,sans-serif;font-size:13px;line-height:1.5;";
      const title = document.createElement("div");
      title.textContent = "\u26A0 Browser Bridge";
      title.style.cssText = "font-weight:700;margin-bottom:6px;color:#b91c1c;";
      const q = document.createElement("div");
      q.textContent = question;
      q.style.cssText = "margin-bottom:12px;word-break:break-word;color:#374151;";
      const actions = document.createElement("div");
      actions.style.cssText = "display:flex;gap:8px;justify-content:flex-end;";
      const deny = document.createElement("button");
      deny.textContent = "Deny";
      deny.style.cssText = "padding:6px 14px;border-radius:8px;border:1px solid #d1d5db;color:#374151;background:#fff;cursor:pointer;font-size:12px;font-weight:600;";
      const allow = document.createElement("button");
      allow.textContent = "Allow";
      allow.style.cssText = "padding:6px 14px;border-radius:8px;border:1px solid #dc2626;background:#dc2626;color:#fff;cursor:pointer;font-size:12px;font-weight:600;";
      actions.appendChild(deny);
      actions.appendChild(allow);
      card.appendChild(title);
      card.appendChild(q);
      card.appendChild(actions);
      host.appendChild(card);
      (document.body || document.documentElement).appendChild(host);
      let done = false;
      const finish = (val) => {
        if (done) return;
        done = true;
        host.remove();
        resolve(val);
      };
      allow.onclick = () => finish(true);
      deny.onclick = () => finish(false);
      setTimeout(() => finish(false), timeoutMs);
    });
  }
  function evalToast(code, url, tabTitle, timeoutMs) {
    function truncate2(s, n) {
      return s.length > n ? s.slice(0, n) + "\u2026" : s;
    }
    return new Promise((resolve) => {
      const host = document.createElement("div");
      host.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;display:flex;flex-direction:column;gap:8px;";
      const card = document.createElement("div");
      card.style.cssText = "box-sizing:border-box;pointer-events:auto;background:#fffbfb;color:#1f2937;border:1.5px solid #dc2626;border-left:4px solid #dc2626;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.16);padding:14px 16px;width:360px;font-family:-apple-system,system-ui,sans-serif;font-size:13px;line-height:1.5;";
      const title = document.createElement("div");
      title.textContent = "\u26A0 Browser Bridge: \u6267\u884C\u786E\u8BA4 (CDP)";
      title.style.cssText = "font-weight:700;color:#b91c1c;margin-bottom:6px;";
      const meta = document.createElement("div");
      meta.textContent = `${truncate2(url || "", 60)} \xB7 \u300C${truncate2(tabTitle || "\u65E0\u6807\u9898", 40)}\u300D`;
      meta.style.cssText = "font-size:11px;color:#6b7280;margin-bottom:8px;font-family:ui-monospace,monospace;word-break:break-all;";
      const pre = document.createElement("pre");
      pre.textContent = code;
      pre.style.cssText = "margin:0 0 10px;padding:8px 10px;max-height:200px;overflow:auto;background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;font-family:ui-monospace,monospace;font-size:12px;line-height:1.45;white-space:pre;color:#111827;";
      const warn = document.createElement("div");
      warn.textContent = "\u4E0A\u9762\u7684\u4EE3\u7801\u5C06\u5728\u8BE5\u9875\u9762\u4EE5\u4F60\u7684\u8EAB\u4EFD\u8FD0\u884C,\u53EF\u80FD\u8BFB\u53D6 token / Cookie / \u53D1\u8D77\u8BF7\u6C42\u3002";
      warn.style.cssText = "font-size:11px;color:#b91c1c;margin-bottom:12px;line-height:1.4;";
      const actions = document.createElement("div");
      actions.style.cssText = "display:flex;gap:8px;justify-content:flex-end;";
      const deny = document.createElement("button");
      deny.textContent = "\u62D2\u7EDD";
      deny.style.cssText = "padding:6px 14px;border-radius:8px;border:1px solid #d1d5db;color:#374151;background:#fff;cursor:pointer;font-size:12px;font-weight:600;";
      const allow = document.createElement("button");
      allow.textContent = "\u5141\u8BB8\u6267\u884C";
      allow.style.cssText = "padding:6px 14px;border-radius:8px;border:1px solid #dc2626;background:#dc2626;color:#fff;cursor:pointer;font-size:12px;font-weight:600;";
      actions.appendChild(deny);
      actions.appendChild(allow);
      card.appendChild(title);
      card.appendChild(meta);
      card.appendChild(pre);
      card.appendChild(warn);
      card.appendChild(actions);
      host.appendChild(card);
      (document.body || document.documentElement).appendChild(host);
      let done = false;
      const finish = (val) => {
        if (done) return;
        done = true;
        document.removeEventListener("keydown", onKey, true);
        host.remove();
        resolve(val);
      };
      const onKey = (e) => {
        if (e.key === "Escape") finish(false);
      };
      document.addEventListener("keydown", onKey, true);
      allow.onclick = () => finish(true);
      deny.onclick = () => finish(false);
      setTimeout(() => finish(false), timeoutMs);
    });
  }

  // src/background/cdp/click-risk.ts
  function isHighRiskClick(t) {
    if (t.role === "button" && t.type === "submit") return true;
    if (t.tagName === "A" && t.hasHref) return true;
    if (t.role === "link") return true;
    return false;
  }
  function describeAction(t, kind) {
    if (kind === "click") {
      if (t.role === "link" || t.tagName === "A") return "navigate";
      if (t.role === "button") return "submit";
      return "click";
    }
    return kind;
  }
  function describeForToast(t) {
    return truncate(t.name || t.role || t.tagName.toLowerCase(), 40);
  }

  // src/background/backends/cdp.ts
  var lastConfirmed = { key: null, until: 0 };
  function originOf(url) {
    if (!url) return "";
    try {
      return new URL(url).origin;
    } catch {
      return url;
    }
  }
  var CdpBackend = class {
    async run(op, args, tab) {
      await ensureAllowed(tab.url);
      if (!isDebuggable(tab.url)) {
        throw new Error(
          `CDP mode cannot control this page (URL scheme not allowed): ${(tab.url || "").slice(0, 80)}`
        );
      }
      const session = await cdpRegistry.get(tab.id);
      switch (op) {
        case "page_snapshot":
          return await session.evaluate(pageSnapshot, [REF_ATTR]);
        case "page_text":
          return await session.evaluate(pageText, []);
        case "page_scroll":
          return await session.evaluate(pageScroll, [
            { direction: args.direction, pixels: args.pixels }
          ]);
        case "page_wait_for":
          try {
            return await session.evaluate(
              pageWaitFor,
              [
                {
                  nav: args.nav,
                  selector: args.selector,
                  text: args.text,
                  timeoutMs: args.timeoutMs
                }
              ],
              { awaitPromise: true }
            );
          } catch (e) {
            const msg = String(e?.message || e);
            if (args.nav && /context was destroyed|Cannot find context|Execution context/i.test(msg)) {
              return { matched: true, nav: true };
            }
            throw e;
          }
        case "page_screenshot":
          return await session.screenshot();
        case "storage_get":
          return await this.storageGet(session, args);
        case "page_fill":
          return await session.evaluate(doFill, [
            REF_ATTR,
            { ref: args.ref, selector: args.selector, value: args.value }
          ]);
        case "page_click":
          return await this.click(session, args, tab);
        case "page_eval":
          return await this.pageEval(session, args, tab);
        default:
          throw new Error(`CDP backend: unsupported op ${op}`);
      }
    }
    // storage_get: read raw values in the page, mask in the SW (always-on).
    async storageGet(session, args) {
      const raw = await session.evaluate(readStorage, [{ type: args.type, key: args.key }]);
      if ("entries" in raw) {
        const masked = {};
        for (const k of Object.keys(raw.entries)) masked[k] = maskString(raw.entries[k]);
        return { ...raw, entries: masked };
      }
      if (raw.found) return { ...raw, value: maskString(raw.value) };
      return raw;
    }
    // page_click with the same high-risk confirmation as the content path.
    async click(session, args, tab) {
      const target = await session.evaluate(probeClickTarget, [
        REF_ATTR,
        { ref: args.ref, selector: args.selector }
      ]);
      if (isHighRiskClick(target)) {
        const confirmEnabled = await getSetting("confirmHighRiskClick");
        if (confirmEnabled !== false) {
          const actionDesc = describeAction(target, "click");
          await this.confirmWithToast(
            session,
            `Click "${describeForToast(target)}"?`,
            // Key the grace window per-tab (not just per-origin) so approving on
            // one tab never silently suppresses the confirm on another same-origin
            // tab — matching the content path, where lastConfirmed is per-tab.
            `${tab.id}:${originOf(tab.url)}:${actionDesc}`,
            actionDesc,
            await getSetting("clickToastTimeoutMs")
          );
        }
      }
      return await session.evaluate(doClick, [REF_ATTR, { ref: args.ref, selector: args.selector }]);
    }
    // Show the click confirmation toast in the page (honoring the grace window).
    async confirmWithToast(session, question, key, actionDesc, timeoutMs) {
      const graceMs = await getSetting("confirmGraceMs");
      if (graceMs > 0 && lastConfirmed.key === key && Date.now() < lastConfirmed.until) {
        return;
      }
      const approved = await session.evaluate(confirmToast, [question, timeoutMs], {
        awaitPromise: true
      });
      if (!approved) throw new Error(`user denied: ${actionDesc}`);
      lastConfirmed = { key, until: Date.now() + graceMs };
    }
    // page_eval: settings gate + enlarged confirm toast + run in MAIN world.
    async pageEval(session, args, tab) {
      const code = args.code;
      if (typeof code !== "string" || !code.trim()) {
        throw new Error("page_eval needs non-empty `code`");
      }
      if (await getSetting("pageEvalEnabled") === false) {
        throw new Error("page_eval disabled in settings");
      }
      if (await getSetting("confirmPageEval") !== false) {
        const key = `${tab.id}:${originOf(tab.url)}:eval`;
        const graceMs = await getSetting("confirmGraceMs");
        const inGrace = graceMs > 0 && lastConfirmed.key === key && Date.now() < lastConfirmed.until;
        if (!inGrace) {
          const approved = await session.evaluate(
            evalToast,
            [code, tab.url || "", tab.title || "", await getSetting("evalToastTimeoutMs")],
            { awaitPromise: true }
          );
          if (!approved) throw new Error("user denied page_eval");
          lastConfirmed = { key, until: Date.now() + graceMs };
        }
      }
      const expression = `(async () => {
${code}
})()`;
      const res = await session.rawEvaluate(expression, { awaitPromise: true });
      if (res.exceptionDetails) {
        const ex = res.exceptionDetails.exception;
        const description = ex?.description || res.exceptionDetails.text || "Error";
        return {
          __evalError: true,
          name: ex?.className || "Error",
          message: description.split("\n")[0],
          stack: truncate(description, 2e3)
        };
      }
      const value = res.result?.value;
      const mask = await getSetting("evalMask") !== false;
      return mask ? maskSensitive(value) : value;
    }
  };

  // src/background/page-backend.ts
  var contentScriptBackend = new ContentScriptBackend();
  var cdpBackend = new CdpBackend();
  function selectBackend(cdpMode) {
    return cdpMode ? cdpBackend : contentScriptBackend;
  }

  // src/background/dispatch.ts
  function assertNotDisabled(op, disabledTools) {
    if (!op || !(op in TOOL_META)) return;
    const decision = decide(op, { disabledTools });
    if (!decision.allowed && decision.reason === "tool disabled in settings") {
      throw new Error(`${decision.reason}: ${op}`);
    }
  }
  async function dispatch(req) {
    const { op } = req;
    const disabled = await getSetting("disabledTools");
    assertNotDisabled(op, Array.isArray(disabled) ? disabled : []);
    switch (req.op) {
      case "tab_list":
        return await tabList();
      case "tab_focus":
        return await tabFocus(req.args.tabId);
      case "tab_open":
        return await tabOpen(req.args.url);
      case "tab_close":
        return await tabClose(req.args.tabId);
      case "page_snapshot_precise":
        return await snapshotPrecise(req.tabId, req.args);
      case "cookie_get":
        return await cookieGet(req.tabId, req.args);
    }
    const tab = await resolveTargetTab(req.tabId);
    const cdpMode = await getSetting("cdpMode") === true;
    const backend = selectBackend(cdpMode);
    return await backend.run(op, req.args, tab);
  }

  // src/background/port.ts
  var NATIVE_HOST = "com.browser_bridge.host";
  var port = null;
  var portOk = false;
  var reconnectTimer = null;
  function isNativeConnected() {
    return portOk;
  }
  function connectNative() {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    try {
      port = chrome.runtime.connectNative(NATIVE_HOST);
      portOk = true;
      console.log("[bb] native host connected");
      port.onMessage.addListener(onNativeMessage);
      port.onDisconnect.addListener(onNativeDisconnect);
    } catch (e) {
      portOk = false;
      console.error("[bb] connectNative threw", e);
      scheduleReconnect();
    }
  }
  function onNativeDisconnect(_p) {
    portOk = false;
    port = null;
    const err = chrome.runtime.lastError;
    console.warn("[bb] native host disconnected:", err?.message || "unknown");
    scheduleReconnect();
  }
  function scheduleReconnect() {
    if (reconnectTimer) return;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connectNative();
    }, 2e3);
  }
  function onNativeMessage(msg) {
    if (!msg || typeof msg.id === "undefined" || !msg.op) {
      console.warn("[bb] malformed BridgeReq", msg);
      return;
    }
    dispatch(msg).then(
      (data) => sendResponse(msg.id, true, data),
      (err) => sendResponse(msg.id, false, void 0, String(err?.message || err || "error"))
    );
  }
  function sendResponse(id, ok, data, error) {
    if (!port) return;
    try {
      port.postMessage({ id, ok, data, error: ok ? void 0 : error });
    } catch (e) {
      console.warn("[bb] postMessage failed", e);
    }
  }

  // src/background/messages.ts
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse2) => {
    if (msg?.type === "resolve_allow") {
      resolvePendingAllow(msg.id, msg.allow).then((r) => sendResponse2(r));
      return true;
    }
    if (msg?.type === "get_allowlist") {
      getAllowlist().then((list) => sendResponse2({ list }));
      return true;
    }
    if (msg?.type === "add_allow") {
      const glob = msg.glob;
      if (typeof glob !== "string" || !glob) {
        sendResponse2({ ok: false, error: "missing glob" });
        return false;
      }
      addAllow(glob).then((list) => sendResponse2({ ok: true, list }));
      return true;
    }
    if (msg?.type === "remove_allow") {
      removeAllow(msg.glob).then((r) => sendResponse2({ ok: true, ...r }));
      return true;
    }
    if (msg?.type === "get_status") {
      sendResponse2({ nativeConnected: isNativeConnected() });
      return false;
    }
    if (msg?.type === "capture_visible_tab") {
      chrome.tabs.captureVisibleTab({ format: "png" }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse2({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse2({ dataUrl });
        }
      });
      return true;
    }
  });

  // src/shared/extension-id.ts
  var PINNED_EXTENSION_ID = "mkjjlmjbcljpcfkfadfmhblmmddkdihf";
  var STORE_EXTENSION_ID = "dgccjfjjilfpkbdllclmkiicajndkfcd";
  var TRUSTED_EXTENSION_IDS = [PINNED_EXTENSION_ID, STORE_EXTENSION_ID];
  function diagnoseExtensionId(runtimeId, expected = TRUSTED_EXTENSION_IDS) {
    if (expected.includes(runtimeId)) {
      return {
        ok: true,
        level: "ok",
        message: `extension id ${runtimeId} is trusted \u2014 native messaging will be accepted`
      };
    }
    return {
      ok: false,
      level: "error",
      message: `extension id mismatch: running=${runtimeId} trusted=${expected.join(", ")}. The native-messaging host pins the trusted ids in allowed_origins, so this extension will be REJECTED and browser-bridge cannot connect. Likely cause: you loaded a build whose manifest lacks the pinned \`key\` (Chrome then derives a path-based id), or an install whose host manifest predates this build's id. Fix: load the built extension/dist that contains the pinned key (or install from the Chrome Web Store), and re-run the installer so allowed_origins trusts your id.`
    };
  }

  // src/background/id-check.ts
  function verifyExtensionId() {
    const d = diagnoseExtensionId(chrome.runtime.id);
    if (d.ok) {
      console.log("[bb]", d.message);
    } else {
      console.error("[bb] \u26A0", d.message);
    }
  }

  // src/background.ts
  verifyExtensionId();
  installCdpLifecycleListeners();
  chrome.runtime.onStartup.addListener(connectNative);
  chrome.runtime.onInstalled.addListener(connectNative);
  connectNative();
})();
