"use strict";
(() => {
  // src/content/util.ts
  function truncate(s, n) {
    return s.length > n ? s.slice(0, n) + "\u2026" : s;
  }

  // src/content/refs.ts
  var REF_ATTR = "data-zcb-ref";
  var refCounter = 0;
  var refMap = /* @__PURE__ */ new Map();
  function resetRefs() {
    refCounter = 0;
    refMap = /* @__PURE__ */ new Map();
  }
  function assignRef(el) {
    let ref = el.getAttribute(REF_ATTR);
    if (ref) {
      const reused = parseInt(ref.slice(1), 10);
      if (!Number.isNaN(reused) && reused > refCounter) refCounter = reused;
    } else {
      refCounter += 1;
      ref = `e${refCounter}`;
      el.setAttribute(REF_ATTR, ref);
    }
    refMap.set(ref, el);
    return ref;
  }
  function resolveTarget(args) {
    if (args.ref) {
      let el = refMap.get(args.ref);
      if (!el) {
        el = document.querySelector(`[${REF_ATTR}="${args.ref}"]`) ?? void 0;
        if (el) refMap.set(args.ref, el);
      }
      if (!el) throw new Error(`ref not found: ${args.ref} \u2014 call page_snapshot again`);
      return el;
    }
    if (args.selector) {
      const el = document.querySelector(args.selector);
      if (!el) throw new Error(`selector matched nothing: ${args.selector}`);
      return el;
    }
    throw new Error("click/fill needs `ref` or `selector`");
  }

  // src/content/snapshot.ts
  function snapshot() {
    resetRefs();
    const out = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (el) => isInteractive(el) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
    });
    let node;
    while (node = walker.nextNode()) {
      const el = node;
      if (!isVisible(el)) continue;
      const ref = assignRef(el);
      out.push({
        ref,
        role: roleOf(el),
        name: nameOf(el),
        selector: cssSelectorOf(el),
        value: previewValue(el)
      });
    }
    return { refCount: out.length, nodes: out, url: location.href, title: document.title };
  }
  function isInteractive(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "iframe" || tag === "frame" || tag === "object" || tag === "embed") return false;
    if (INTERACTIVE_TAGS.has(tag)) return true;
    const role = el.getAttribute("role");
    if (role && INTERACTIVE_ROLES.has(role)) return true;
    if (el.hasAttribute("onclick")) return true;
    if (el.tabIndex >= 0) return true;
    return false;
  }
  var INTERACTIVE_TAGS = /* @__PURE__ */ new Set([
    "a",
    "button",
    "input",
    "textarea",
    "select",
    "summary",
    "details",
    "label",
    "option",
    "optgroup"
  ]);
  var INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "checkbox",
    "radio",
    "textbox",
    "searchbox",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "combobox",
    "listbox",
    "option",
    "switch",
    "treeitem"
  ]);
  function roleOf(el) {
    const explicit = el.getAttribute("role");
    if (explicit) return explicit;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (tag === "a" && el.hasAttribute("href")) return "link";
    if (tag === "button") return "button";
    if (tag === "input") {
      if (type === "checkbox") return "checkbox";
      if (type === "radio") return "radio";
      if (type === "submit" || type === "button" || type === "reset") return "button";
      return "textbox";
    }
    if (tag === "textarea") return "textbox";
    if (tag === "select") return "listbox";
    if (tag === "summary") return "button";
    return tag;
  }
  function nameOf(el) {
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      const parts = labelledBy.split(/\s+/).map((id) => document.getElementById(id)).filter((n) => n !== null).map((n) => n.innerText || n.textContent || "").join(" ").trim();
      if (parts) return truncate(parts, 120);
    }
    const aria = el.getAttribute("aria-label");
    if (aria && aria.trim()) return truncate(aria.trim(), 120);
    const labelFor = document.querySelector(`label[for="${el.id}"]`);
    if (labelFor) {
      const t = (labelFor.innerText || "").trim();
      if (t) return truncate(t, 120);
    }
    const wrapping = el.closest("label");
    if (wrapping && wrapping !== labelFor) {
      const t = (wrapping.innerText || "").trim();
      if (t) return truncate(t, 120);
    }
    if (el.title && el.title.trim()) return truncate(el.title.trim(), 120);
    const txt = (el.innerText || el.textContent || "").trim();
    if (txt) return truncate(txt, 120);
    const placeholder = el.getAttribute("placeholder");
    if (placeholder) return truncate(placeholder, 120);
    const alt = el.getAttribute("alt");
    if (alt) return truncate(alt, 120);
    return "";
  }
  function previewValue(el) {
    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT") {
      const field = el;
      const v = field.value || "";
      if (field.type === "password") return v ? "\u2022\u2022\u2022\u2022\u2022\u2022" : "";
      return truncate(v, 60);
    }
    return void 0;
  }
  function isVisible(el) {
    if (!el || !el.getClientRects) return false;
    const rects = el.getClientRects();
    if (rects.length === 0) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    let cur = el;
    while (cur && cur.nodeType === 1) {
      if (cur.getAttribute("aria-hidden") === "true") return false;
      cur = cur.parentElement;
    }
    return true;
  }
  function cssSelectorOf(el) {
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.body) {
      let part = cur.tagName.toLowerCase();
      if (cur.id) {
        part += `#${cur.id}`;
        parts.unshift(part);
        break;
      }
      const parent = cur.parentElement;
      if (parent) {
        const tag = cur.tagName;
        const siblings = Array.from(parent.children).filter((c) => c.tagName === tag);
        if (siblings.length > 1) {
          const idx = siblings.indexOf(cur) + 1;
          part += `:nth-of-type(${idx})`;
        }
      }
      parts.unshift(part);
      cur = cur.parentElement;
    }
    return parts.join(" > ");
  }

  // src/content/actions.ts
  async function click(args) {
    const el = resolveTarget(args);
    el.scrollIntoView({ block: "center" });
    el.focus?.();
    el.click();
    return { clicked: args.ref || args.selector, role: roleOf(el) };
  }
  async function fill(args) {
    const el = resolveTarget(args);
    const value = args.value ?? "";
    await setNativeValue(el, value);
    return { filled: args.ref || args.selector };
  }
  function setNativeValue(el, value) {
    return new Promise((resolve, reject) => {
      try {
        el.focus?.();
        const field = el;
        const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) {
          setter.call(el, value);
        } else {
          field.value = value;
        }
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        resolve();
      } catch (e) {
        reject(e);
      }
    });
  }
  function text() {
    const txt = (document.body?.innerText || "").replace(/\b\d{12,19}\b/g, "\u2022\u2022\u2022\u2022\u2022\u2022");
    return { text: truncate(txt, 2e4), url: location.href };
  }
  async function screenshot() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: "capture_visible_tab" }, (resp) => {
        if (chrome.runtime.lastError || !resp || !resp.dataUrl) {
          reject(new Error(chrome.runtime.lastError?.message || "capture failed"));
        } else {
          resolve({ image: resp.dataUrl.split(",", 2)[1], mimeType: "image/png" });
        }
      });
    });
  }
  function scroll(args) {
    if (typeof args.pixels === "number") {
      window.scrollBy(0, args.pixels);
    } else if (args.direction) {
      const dh = window.innerHeight * 0.9;
      switch (args.direction) {
        case "down":
          window.scrollBy(0, dh);
          break;
        case "up":
          window.scrollBy(0, -dh);
          break;
        case "top":
          window.scrollTo(0, 0);
          break;
        case "bottom":
          window.scrollTo(0, document.body.scrollHeight);
          break;
      }
    } else {
      throw new Error("scroll needs `direction` or `pixels`");
    }
    return { scrollY: window.scrollY, scrollX: window.scrollX };
  }

  // src/content/wait.ts
  function waitFor(args) {
    const timeoutMs = args.timeoutMs ?? 3e4;
    const until = args.until === "domcontentloaded" ? "domcontentloaded" : "load";
    const start = Date.now();
    return new Promise((resolve, reject) => {
      let done = false;
      const navResult = () => ({
        matched: true,
        nav: true,
        url: location.href,
        readyState: document.readyState
      });
      const onReady = () => finish(resolve, navResult());
      const finish = (fn, value) => {
        if (done) return;
        done = true;
        window.removeEventListener("load", onReady, true);
        document.removeEventListener("DOMContentLoaded", onReady, true);
        fn(value);
      };
      if (args.nav) {
        if (until === "domcontentloaded") {
          if (document.readyState !== "loading") return finish(resolve, navResult());
          document.addEventListener("DOMContentLoaded", onReady, true);
        } else {
          if (document.readyState === "complete") return finish(resolve, navResult());
          window.addEventListener("load", onReady, true);
        }
      }
      const tick = () => {
        if (done) return;
        if (args.selector) {
          if (document.querySelector(args.selector)) {
            return finish(resolve, { matched: true, selector: args.selector });
          }
        }
        if (args.text) {
          if ((document.body?.innerText || "").includes(args.text)) {
            return finish(resolve, { matched: true, text: args.text });
          }
        }
        if (Date.now() - start > timeoutMs) {
          return finish(reject, new Error(`wait_for timed out after ${timeoutMs}ms`));
        }
        setTimeout(tick, 150);
      };
      tick();
    });
  }

  // src/shared/masking.ts
  var SENSITIVE_KEY = /(token|cookie|password|passwd|secret|api[_-]?key|auth|cred|session)/i;
  function maskPatterns(s) {
    let out = s;
    out = out.replace(/ey[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g, "\u2022\u2022\u2022\u2022[jwt]");
    out = out.replace(/\b[a-fA-F0-9]{32,}\b/g, "\u2022\u2022\u2022\u2022[hex]");
    out = out.replace(/\b\d{12,}\b/g, "\u2022\u2022\u2022\u2022[num]");
    out = out.replace(
      /(?:bearer|token|password|secret|api[_-]?key)\s*[:=]\s*\S+/gi,
      "\u2022\u2022\u2022\u2022[redacted]"
    );
    return out;
  }
  function maskString(s) {
    if (s.length < 8) return s;
    const out = maskPatterns(s);
    if (SENSITIVE_KEY.test(s) && s.length >= 8 && !/\s/.test(s)) {
      return "\u2022\u2022\u2022\u2022[sensitive]";
    }
    return out;
  }
  function maskNumber(n) {
    if (Number.isInteger(n) && Math.abs(n) >= 1e11) return "\u2022\u2022\u2022\u2022[num]";
    return n;
  }
  function maskKeyName(key) {
    return SENSITIVE_KEY.test(key) ? "\u2022\u2022\u2022\u2022" + key.slice(-2) : key;
  }
  function maskSensitive(value) {
    if (value === null || value === void 0) return value;
    const t = typeof value;
    if (t === "string") return maskString(value);
    if (t === "number") return maskNumber(value);
    if (t === "boolean") return value;
    if (Array.isArray(value)) return value.map(maskSensitive);
    if (t === "object") {
      const out = {};
      for (const k of Object.keys(value)) {
        out[maskKeyName(k)] = maskSensitive(value[k]);
      }
      return out;
    }
    return value;
  }

  // src/content/eval.ts
  async function runEval(args) {
    const code = args.code;
    if (typeof code !== "string" || !code.trim()) {
      throw new Error("page_eval needs non-empty `code`");
    }
    let result;
    try {
      const fn = new Function('"use strict";\nreturn (async () => {\n' + code + "\n})();");
      result = await fn();
    } catch (e) {
      return {
        __evalError: true,
        name: e?.name || "Error",
        message: String(e?.message || e),
        stack: truncate(String(e?.stack || ""), 2e3)
      };
    }
    return maskSensitive(serializeResult(result));
  }
  function serializeResult(value, seen = /* @__PURE__ */ new WeakSet(), depth = 0) {
    if (depth > 50) return "[depth limit]";
    if (value === null || value === void 0) return value;
    const t = typeof value;
    if (t === "string") return truncate(value, 1e4);
    if (t === "number" || t === "boolean") return value;
    if (t === "bigint") return `[BigInt:${value.toString()}]`;
    if (t === "symbol") return `[Symbol:${value.toString()}]`;
    if (t === "function") return `[function:${value.name || "anonymous"}]`;
    if (t === "object") {
      if (value instanceof Error) {
        return { __error: true, name: value.name, message: value.message };
      }
      if (value instanceof Element) {
        const id = value.id ? `#${value.id}` : "";
        return `<${value.tagName.toLowerCase()}${id}>`;
      }
      if (value instanceof Node) {
        return `<${value.nodeName}>`;
      }
      if (seen.has(value)) return "[Circular]";
      seen.add(value);
      try {
        if (Array.isArray(value)) {
          if (value.length > 1e3) return `[Array length=${value.length}, truncated]`;
          return value.slice(0, 1e3).map((v) => serializeResult(v, seen, depth + 1));
        }
        if (value instanceof Map) {
          const obj = {};
          let i = 0;
          for (const [k, v] of value) {
            obj[String(k)] = serializeResult(v, seen, depth + 1);
            if (++i > 1e3) break;
          }
          return { __Map: obj };
        }
        if (value instanceof Set) {
          return {
            __Set: Array.from(value).slice(0, 1e3).map((v) => serializeResult(v, seen, depth + 1))
          };
        }
        if (value instanceof Date) return { __Date: value.toISOString() };
        if (value instanceof RegExp) return { __RegExp: value.toString() };
        const out = {};
        let count = 0;
        for (const key of Object.keys(value)) {
          if (count++ > 1e3) {
            out.__truncated = true;
            break;
          }
          out[key] = serializeResult(value[key], seen, depth + 1);
        }
        return out;
      } finally {
        seen.delete(value);
      }
    }
    return String(value);
  }

  // src/content/storage.ts
  function storageGet(args) {
    const type = args.type === "session" ? "session" : "local";
    const key = args.key;
    let store;
    try {
      store = type === "session" ? window.sessionStorage : window.localStorage;
    } catch (e) {
      throw new Error(`storage unavailable: ${e.message}`, { cause: e });
    }
    if (key !== void 0 && key !== null && key !== "") {
      const raw = store.getItem(key);
      if (raw === null) return { key, found: false };
      return { key, found: true, value: maskString(raw) };
    }
    const entries = {};
    let count = 0;
    const MAX = 500;
    for (let i = 0; i < store.length && count < MAX; i++) {
      const k = store.key(i);
      if (k === null) continue;
      try {
        entries[k] = maskString(store.getItem(k) || "");
      } catch {
        entries[k] = "[unreadable]";
      }
      count++;
    }
    const truncated = store.length > MAX;
    return { type, entries, count, truncated, totalKeys: store.length };
  }

  // src/content/toast.ts
  function showInfoToast(message) {
    return new Promise((resolve) => {
      const host = ensureToastHost();
      const card = document.createElement("div");
      card.className = "zcb-toast-card zcb-info-card";
      card.innerHTML = `
        <div class="zcb-info-title">Browser Bridge</div>
        <div class="zcb-info-text"></div>
        <div class="zcb-info-actions">
          <button class="zcb-info-cancel">Cancel</button>
        </div>`;
      card.querySelector(".zcb-info-text").textContent = message;
      host.appendChild(card);
      let done = false;
      const finish = (proceed) => {
        if (done) return;
        done = true;
        card.classList.add("zcb-toast-out");
        setTimeout(() => card.remove(), 150);
        resolve(proceed);
      };
      card.querySelector(".zcb-info-cancel").onclick = () => finish(false);
      setTimeout(() => finish(true), 8e3);
    });
  }
  function ensureToastHost() {
    let host = document.getElementById("__zcb_toast_host");
    if (!host) {
      host = document.createElement("div");
      host.id = "__zcb_toast_host";
      host.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;display:flex;flex-direction:column;gap:8px;pointer-events:none;";
      (document.body || document.documentElement).appendChild(host);
    }
    return host;
  }

  // src/content/handle.ts
  async function handle(msg) {
    const { op, args } = msg;
    switch (op) {
      case "ping":
        return { pong: true };
      case "page_snapshot":
        return snapshot();
      case "page_click":
        return await click(args);
      case "page_fill":
        return await fill(args);
      case "page_text":
        return text();
      case "page_screenshot":
        return await screenshot();
      case "page_scroll":
        return scroll(args);
      case "page_wait_for":
        return await waitFor(args);
      case "page_eval":
        return await runEval(args);
      case "storage_get":
        return storageGet(args);
      case "_info_toast":
        return await showInfoToast(args.message || "");
      default:
        throw new Error(`content: unknown op ${op}`);
    }
  }

  // src/content.ts
  (() => {
    if (window.__browserBridgeLoaded) return;
    window.__browserBridgeLoaded = true;
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      handle(msg).then((data) => sendResponse(data || {})).catch((e) => sendResponse({ __error: String(e?.message || e) }));
      return true;
    });
  })();
})();
