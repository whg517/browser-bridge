"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULTS = {
    disabledTools: [],
    // string[] of tool/op names that are blocked
    allowAllSites: false,
    cdpMode: false
    // route ALL page ops through chrome.debugger (CDP). See ADR-0017.
  };

  // src/shared/ops.ts
  var TOOLS = [
    { op: "tab_list", desc: "List all tabs" },
    { op: "tab_focus", desc: "Switch to a tab" },
    { op: "tab_open", desc: "Open a new tab (allowlist required)" },
    { op: "tab_close", desc: "Close a tab" },
    { op: "page_snapshot", desc: "Snapshot interactive elements" },
    { op: "page_click", desc: "Click an element" },
    { op: "page_fill", desc: "Fill a form field" },
    { op: "page_text", desc: "Read visible page text" },
    { op: "page_screenshot", desc: "Capture the viewport" },
    { op: "page_scroll", desc: "Scroll the page" },
    { op: "page_wait_for", desc: "Wait for a condition" },
    { op: "page_eval", desc: "Execute arbitrary JS (high-risk)" },
    { op: "page_snapshot_precise", desc: "Precise snapshot (via debugger)" },
    { op: "cookie_get", desc: "Read cookies (redacted)" },
    { op: "storage_get", desc: "Read localStorage/sessionStorage (redacted)" }
  ];
  var OP_NAMES = TOOLS.map((t) => t.op);

  // src/options.ts
  function $(id) {
    return document.getElementById(id);
  }
  async function loadSettings() {
    const keys = Object.keys(DEFAULTS);
    const stored = await chrome.storage.local.get(keys);
    return { ...DEFAULTS, ...stored };
  }
  async function saveSetting(key, value) {
    await chrome.storage.local.set({ [key]: value });
    flashToast("Saved");
  }
  var toastTimer = null;
  function flashToast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.add("show");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 1200);
  }
  function wireAllowAllSites() {
    const input = $("allowAllSites");
    const warn = $("allowAllSites-warn");
    const card = $("card-allowAllSites");
    input.addEventListener("change", async (e) => {
      const target = e.target;
      const checked = target.checked;
      if (checked) {
        const granted = await chrome.permissions.request({
          origins: ["<all_urls>"]
        });
        if (!granted) {
          target.checked = false;
          flashToast("<all_urls> not granted; kept per-site approval");
          return;
        }
      } else {
        await chrome.permissions.remove({ origins: ["<all_urls>"] });
      }
      if (warn) warn.style.display = checked ? "block" : "none";
      if (card) card.classList.toggle("danger", checked);
      await saveSetting("allowAllSites", checked);
      flashToast(checked ? "All sites allowed" : "Restored per-site approval");
    });
  }
  function renderToolsGrid(disabledTools) {
    const grid = $("tools-grid");
    const disabled = new Set(Array.isArray(disabledTools) ? disabledTools : []);
    grid.innerHTML = TOOLS.map((t) => {
      const checked = disabled.has(t.op) ? "" : "checked";
      return `<label class="tool"><input type="checkbox" data-op="${escapeAttr(t.op)}" ${checked} /><div><div class="name">${escapeHtml(t.op)}</div><div class="tdesc">${escapeHtml(t.desc)}</div></div></label>`;
    }).join("");
    grid.querySelectorAll("input[type=checkbox]").forEach((cb) => {
      cb.addEventListener("change", async () => {
        const all = grid.querySelectorAll("input[type=checkbox]");
        const next = [];
        all.forEach((c) => {
          if (!c.checked) next.push(c.getAttribute("data-op"));
        });
        await saveSetting("disabledTools", next);
      });
    });
  }
  async function refreshAllowlist() {
    const resp = await send({ type: "get_allowlist" });
    const list = resp?.list || [];
    const box = $("site-list");
    if (list.length === 0) {
      box.innerHTML = `<div class="empty">No sites allowed yet.</div>`;
      return;
    }
    box.innerHTML = list.map(
      (g) => `<div class="item"><code>${escapeHtml(g)}</code><button class="danger" data-glob="${escapeAttr(g)}">Remove</button></div>`
    ).join("");
    box.querySelectorAll("button").forEach((b) => {
      b.onclick = async () => {
        const glob = b.getAttribute("data-glob");
        await send({ type: "remove_allow", glob });
        refreshAllowlist();
        flashToast("Removed");
      };
    });
  }
  function wireAddSite() {
    const input = $("new-site");
    const btn = $("add-site");
    async function add() {
      const v = input.value.trim();
      if (!v) return;
      if (!/^https?:\/\/[^/]+\//.test(v) && !/^https?:\/\/[^/]+$/.test(v)) {
        flashToast("Format should be https://domain/*");
        return;
      }
      let glob;
      try {
        const u = new URL(v);
        glob = `${u.protocol}//${u.host}/*`;
      } catch (_) {
        flashToast("Failed to parse URL");
        return;
      }
      const resp = await send({ type: "add_allow", glob });
      if (resp && resp.ok) {
        input.value = "";
        refreshAllowlist();
        flashToast("Added");
      } else {
        flashToast(resp?.error || "Failed to add");
      }
    }
    btn.onclick = add;
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") add();
    });
  }
  function send(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (resp) => resolve(resp));
    });
  }
  var HTML_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);
  }
  function escapeAttr(s) {
    return escapeHtml(s);
  }
  (async function init() {
    const s = await loadSettings();
    {
      const input = $("cdpMode");
      const warn = $("cdpMode-warn");
      const card = $("card-cdpMode");
      const sync = (on) => {
        if (warn) warn.style.display = on ? "block" : "none";
        if (card) card.classList.toggle("danger", on);
      };
      input.checked = s.cdpMode === true;
      sync(input.checked);
      input.addEventListener("change", (e) => {
        const on = e.target.checked;
        sync(on);
        saveSetting("cdpMode", on);
      });
    }
    {
      const held = await chrome.permissions.contains({ origins: ["<all_urls>"] });
      const effective = s.allowAllSites === true && held;
      const input = $("allowAllSites");
      input.checked = effective;
      if (effective !== (s.allowAllSites === true)) {
        await chrome.storage.local.set({ allowAllSites: effective });
      }
      const warn = $("allowAllSites-warn");
      if (warn) warn.style.display = effective ? "block" : "none";
      const card = $("card-allowAllSites");
      if (card) card.classList.toggle("danger", effective);
      wireAllowAllSites();
    }
    renderToolsGrid(s.disabledTools);
    await refreshAllowlist();
    wireAddSite();
  })();
})();
