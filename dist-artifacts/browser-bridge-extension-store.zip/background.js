"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULTS = {
    disabledTools: [],
    // string[] of tool/op names that are blocked
    allowAllSites: false,
    cdpMode: false
    // route ALL page ops through chrome.debugger (CDP). See ADR-0017.
  };
  function getSetting(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get(key, (r) => {
        const v = r[key];
        resolve(v === void 0 ? DEFAULTS[key] : v);
      });
    });
  }

  // src/shared/allowlist.ts
  function originGlobOf(url) {
    try {
      const u = new URL(url);
      return `${u.protocol}//${u.host}/*`;
    } catch {
      return null;
    }
  }
  function hostFromOriginGlob(glob) {
    try {
      return new URL(glob.replace(/\*$/, "")).host.toLowerCase();
    } catch {
      return null;
    }
  }
  function normalizeCookieDomain(domain) {
    if (typeof domain !== "string") return null;
    let d = domain.trim().toLowerCase();
    if (!d || d.includes("://") || d.includes("/") || d.includes("*")) return null;
    while (d.startsWith(".")) d = d.slice(1);
    return d || null;
  }
  function matchesAny(glob, list) {
    return list.some((pattern) => simpleMatch(pattern, glob));
  }
  function simpleMatch(pattern, target) {
    if (pattern === target) return true;
    if (pattern.endsWith("/*")) {
      const base = pattern.slice(0, -2);
      return target === base || target.startsWith(base + "/");
    }
    if (pattern.endsWith("*")) {
      return target.startsWith(pattern.slice(0, -1));
    }
    return false;
  }
  function globToPermissionPattern(glob) {
    if (typeof glob !== "string" || !glob) return null;
    return glob.endsWith("/*") ? glob : glob + "*";
  }

  // src/background/allowlist-store.ts
  var STORAGE_KEY = "allowlist";
  async function getAllowlist() {
    const { [STORAGE_KEY]: list } = await chrome.storage.local.get(STORAGE_KEY);
    return Array.isArray(list) ? list : [];
  }
  async function setAllowlist(list) {
    await chrome.storage.local.set({ [STORAGE_KEY]: list });
  }
  async function ensureDomainAllowed(domain) {
    const host = normalizeCookieDomain(domain);
    if (!host) throw new Error(`invalid cookie domain: ${domain}`);
    if (await getSetting("allowAllSites") === true) return;
    const list = await getAllowlist();
    const allowed = list.some((glob) => hostFromOriginGlob(glob) === host);
    if (!allowed) {
      throw new Error(
        `cookie domain not allowed by user: ${domain}. Use a URL for the active allowlisted origin, or approve that exact host first.`
      );
    }
  }
  async function ensureAllowed(url) {
    const glob = originGlobOf(url);
    if (!glob) throw new Error(`cannot parse url: ${url}`);
    if (await getSetting("allowAllSites") === true) return;
    const list = await getAllowlist();
    if (matchesAny(glob, list)) return;
    const reason = await promptUserForAllow(glob);
    if (reason === "denied") {
      throw new Error(`The user denied browser-bridge access to ${glob}.`);
    }
    if (reason === "timeout") {
      throw new Error(
        `Approval for ${glob} timed out (no response in 60s). Retry this tool call, then click the Browser Bridge toolbar icon (it shows a red "!" badge) and choose Allow within 60s. Or pre-approve the origin in the extension's Settings \u2192 Allowed sites.`
      );
    }
  }
  function promptUserForAllow(glob) {
    return new Promise((resolve) => {
      const reqId = `allow_${Date.now()}`;
      pendingAllowRequests.set(reqId, { glob, resolve });
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#d9534f" });
      chrome.storage.local.set({ pendingAllow: { id: reqId, glob } });
      setTimeout(() => {
        if (pendingAllowRequests.has(reqId)) {
          pendingAllowRequests.delete(reqId);
          chrome.storage.local.remove("pendingAllow");
          maybeClearBadge();
          resolve("timeout");
        }
      }, 6e4);
    });
  }
  var pendingAllowRequests = /* @__PURE__ */ new Map();
  function maybeClearBadge() {
    if (pendingAllowRequests.size === 0) {
      chrome.action.setBadgeText({ text: "" });
    }
  }
  async function resolvePendingAllow(id, allow) {
    const pending = pendingAllowRequests.get(id);
    if (!pending) return { ok: false, error: "no such pending request" };
    pendingAllowRequests.delete(id);
    chrome.storage.local.remove("pendingAllow");
    maybeClearBadge();
    if (allow) {
      const list = await getAllowlist();
      if (!list.includes(pending.glob)) list.push(pending.glob);
      await setAllowlist(list);
      pending.resolve("granted");
    } else {
      pending.resolve("denied");
    }
    return { ok: true };
  }
  async function addAllow(glob) {
    const list = await getAllowlist();
    if (!list.includes(glob)) list.push(glob);
    await setAllowlist(list);
    return list;
  }
  async function removeAllow(glob) {
    const list = await getAllowlist();
    const next = list.filter((g) => g !== glob);
    await setAllowlist(next);
    const pattern = globToPermissionPattern(glob);
    if (!pattern) return { list: next, permissionRemoved: false };
    return new Promise((resolve) => {
      chrome.permissions.remove({ origins: [pattern] }, (removed) => {
        resolve({
          list: next,
          permissionRemoved: Boolean(removed),
          permissionError: chrome.runtime.lastError?.message
        });
      });
    });
  }

  // src/shared/ops.ts
  var TOOLS = [
    { op: "tab_list", desc: "List all tabs" },
    { op: "tab_focus", desc: "Switch to a tab" },
    { op: "tab_open", desc: "Open a new tab (allowlist required)" },
    { op: "tab_close", desc: "Close a tab" },
    { op: "page_snapshot", desc: "Snapshot interactive elements" },
    { op: "page_click", desc: "Click an element" },
    { op: "page_fill", desc: "Fill a form field" },
    { op: "page_text", desc: "Read visible page text" },
    { op: "page_screenshot", desc: "Capture the viewport" },
    { op: "page_scroll", desc: "Scroll the page" },
    { op: "page_wait_for", desc: "Wait for a condition" },
    { op: "page_eval", desc: "Execute arbitrary JS (high-risk)" },
    { op: "page_snapshot_precise", desc: "Precise snapshot (via debugger)" },
    { op: "cookie_get", desc: "Read cookies (redacted)" },
    { op: "storage_get", desc: "Read localStorage/sessionStorage (redacted)" }
  ];
  var OP_NAMES = TOOLS.map((t) => t.op);
  var TOOL_META = {
    tab_list: {
      risk: "low",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    tab_focus: {
      risk: "low",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    tab_open: {
      risk: "medium",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    tab_close: {
      risk: "high",
      scope: "tab",
      permission: "tabs",
      confirmation: "none"
    },
    page_snapshot: {
      risk: "low",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_click: {
      risk: "high",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_fill: {
      risk: "high",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_text: {
      risk: "medium",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_screenshot: {
      risk: "medium",
      scope: "page",
      permission: "tabs",
      confirmation: "none"
    },
    page_scroll: {
      risk: "low",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_wait_for: {
      risk: "low",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_eval: {
      risk: "critical",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    },
    page_snapshot_precise: {
      risk: "medium",
      scope: "page",
      permission: "debugger",
      confirmation: "warn"
    },
    cookie_get: {
      risk: "high",
      scope: "tab",
      permission: "cookies",
      confirmation: "none"
    },
    storage_get: {
      risk: "high",
      scope: "page",
      permission: "scripting",
      confirmation: "none"
    }
  };

  // src/background/policy.ts
  var UNKNOWN_RISK = "critical";
  function confirmationFor(confirmation) {
    switch (confirmation) {
      case "none":
        return { requiresConfirmation: false, confirmationChannel: "none" };
      default:
        return { requiresConfirmation: true, confirmationChannel: "extension-ui" };
    }
  }
  function decide(op, ctx) {
    const meta = TOOL_META[op];
    if (!meta) {
      return {
        allowed: false,
        risk: UNKNOWN_RISK,
        requiresConfirmation: true,
        confirmationChannel: "extension-ui",
        reason: "unknown tool"
      };
    }
    const { requiresConfirmation, confirmationChannel } = confirmationFor(meta.confirmation);
    if (ctx.disabledTools.includes(op)) {
      return {
        allowed: false,
        risk: meta.risk,
        requiresConfirmation,
        confirmationChannel,
        reason: "tool disabled in settings"
      };
    }
    return {
      allowed: true,
      risk: meta.risk,
      requiresConfirmation,
      confirmationChannel,
      reason: requiresConfirmation ? "allowed; requires confirmation" : "allowed"
    };
  }

  // src/background/tabs.ts
  async function resolveTargetTab(maybeTabId) {
    if (maybeTabId) {
      return await chrome.tabs.get(maybeTabId);
    }
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!active) throw new Error("no active tab");
    return active;
  }
  async function injectIfNeeded(tabId) {
    try {
      await chrome.tabs.sendMessage(tabId, { op: "ping" });
    } catch {
      await chrome.tabs.get(tabId);
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });
      try {
        await chrome.scripting.insertCSS({
          target: { tabId },
          files: ["toast.css"]
        });
      } catch (_) {
      }
    }
  }
  async function tabList() {
    const tabs = await chrome.tabs.query({});
    return tabs.map((t) => ({
      id: t.id,
      title: t.title,
      url: t.url,
      active: t.active,
      windowId: t.windowId,
      groupId: typeof t.groupId === "number" && t.groupId >= 0 ? t.groupId : void 0
    }));
  }
  async function tabFocus(tabId) {
    const t = await chrome.tabs.update(tabId, { active: true });
    if (!t) throw new Error(`tab ${tabId} not found`);
    await chrome.windows.update(t.windowId, { focused: true });
    return { focused: tabId };
  }
  var WORKSPACE_TITLE = "Browser Bridge";
  var WORKSPACE_COLOR = "blue";
  async function tabOpen(url) {
    await ensureAllowed(url);
    const t = await chrome.tabs.create({ url });
    let groupId;
    if (typeof t.id === "number") {
      groupId = await addToWorkspaceGroup(t.id, t.windowId);
    }
    return { opened: t.id, url, groupId };
  }
  async function addToWorkspaceGroup(tabId, windowId) {
    try {
      const groups = await chrome.tabGroups.query(windowId != null ? { windowId } : {});
      const existing = groups.find((g) => g.title === WORKSPACE_TITLE);
      if (existing) {
        await chrome.tabs.group({ tabIds: [tabId], groupId: existing.id });
        return existing.id;
      }
      const groupId = await chrome.tabs.group({ tabIds: [tabId] });
      await chrome.tabGroups.update(groupId, { title: WORKSPACE_TITLE, color: WORKSPACE_COLOR });
      return groupId;
    } catch (e) {
      console.warn("[bb] tab grouping failed:", e?.message || e);
      return void 0;
    }
  }
  async function tabClose(tabId) {
    await chrome.tabs.get(tabId);
    await chrome.tabs.remove(tabId);
    return { closed: tabId };
  }

  // src/background/cdp/session.ts
  var NON_DEBUGGABLE = [
    /^chrome:\/\//i,
    /^chrome-extension:\/\//i,
    /^https:\/\/chrome\.google\.com\/webstore/i,
    /^view-source:/i,
    /^about:/i,
    /^edge:\/\//i
  ];
  function isDebuggable(url) {
    if (!url) return false;
    return !NON_DEBUGGABLE.some((re) => re.test(url));
  }
  function dbgAttach(tabId) {
    return new Promise((resolve, reject) => {
      chrome.debugger.attach({ tabId }, "1.3", () => {
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else resolve();
      });
    });
  }
  function dbgDetach(tabId) {
    return new Promise((resolve) => {
      chrome.debugger.detach({ tabId }, () => resolve());
    });
  }
  function dbgSend(tabId, method, params = {}) {
    return new Promise((resolve, reject) => {
      chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else resolve(result);
      });
    });
  }
  function buildEvaluateExpression(fn, args = []) {
    return `(${fn.toString()}).apply(undefined, ${JSON.stringify(args)})`;
  }
  function evalExceptionMessage(details) {
    const desc = details.exception?.description;
    if (desc) return desc.split("\n")[0];
    return details.text || "evaluation failed";
  }
  var CdpSession = class {
    tabId;
    attached = false;
    attaching = null;
    constructor(tabId) {
      this.tabId = tabId;
    }
    get isAttached() {
      return this.attached;
    }
    // Attach the debugger to this tab. Idempotent: a no-op if already attached.
    // The banner ("Started debugging this browser") stays up until detach — by
    // design in CDP mode (ADR-0017), the registry keeps sessions attached.
    async attach() {
      if (this.attached) return;
      if (!this.attaching) {
        this.attaching = this.doAttach().finally(() => {
          this.attaching = null;
        });
      }
      return this.attaching;
    }
    async doAttach() {
      try {
        await dbgAttach(this.tabId);
      } catch (e) {
        const msg = String(e.message || e);
        if (/another debugger/i.test(msg)) {
          throw new Error(
            "This tab has DevTools open; CDP mode cannot attach. Close DevTools and try again.",
            {
              cause: e
            }
          );
        }
        throw e;
      }
      this.attached = true;
    }
    async detach() {
      if (!this.attached) return;
      this.attached = false;
      await dbgDetach(this.tabId);
    }
    // Mark the session as detached WITHOUT calling chrome.debugger.detach — for
    // the case where Chrome already detached us (onDetach event).
    markDetached() {
      this.attached = false;
    }
    send(method, params = {}) {
      return dbgSend(this.tabId, method, params);
    }
    // Evaluate a page function (or raw expression) in the page's MAIN world.
    // returnByValue serializes the result to JSON. `awaitPromise` resolves a
    // returned promise before serializing (needed for wait_for / toasts).
    // Throws on an uncaught page exception.
    async evaluate(fnOrExpr, args = [], opts = {}) {
      const expression = typeof fnOrExpr === "function" ? buildEvaluateExpression(fnOrExpr, args) : fnOrExpr;
      const res = await this.send("Runtime.evaluate", {
        expression,
        returnByValue: true,
        awaitPromise: opts.awaitPromise ?? false,
        userGesture: true
      });
      if (res.exceptionDetails) {
        throw new Error(evalExceptionMessage(res.exceptionDetails));
      }
      return res.result?.value;
    }
    // Runtime.evaluate that returns the raw response (result + exceptionDetails)
    // so callers can map a page exception to structured data (page_eval).
    rawEvaluate(expression, opts = {}) {
      return this.send("Runtime.evaluate", {
        expression,
        returnByValue: true,
        awaitPromise: opts.awaitPromise ?? false,
        userGesture: true
      });
    }
    // Screenshot the viewport via CDP (preferred over a page-fn). Returns the
    // base64 PNG payload without the data: URL prefix, matching the content path.
    async screenshot() {
      const res = await this.send("Page.captureScreenshot", {
        format: "png"
      });
      return { image: res.data ?? "", mimeType: "image/png" };
    }
  };

  // src/background/cdp/registry.ts
  var CdpSessionRegistry = class {
    sessions = /* @__PURE__ */ new Map();
    // Get (creating + attaching lazily) the session for a tab. attach() is
    // idempotent, so this is cheap on the hot path.
    async get(tabId) {
      let session = this.sessions.get(tabId);
      if (!session) {
        session = new CdpSession(tabId);
        this.sessions.set(tabId, session);
      }
      try {
        await session.attach();
      } catch (e) {
        if (!session.isAttached) this.sessions.delete(tabId);
        throw e;
      }
      return session;
    }
    // Explicit teardown: detach and forget. Safe to call for an unknown tab.
    async teardown(tabId) {
      const session = this.sessions.get(tabId);
      if (!session) return;
      this.sessions.delete(tabId);
      await session.detach();
    }
    async teardownAll() {
      const sessions = [...this.sessions.values()];
      this.sessions.clear();
      await Promise.all(sessions.map((s) => s.detach()));
    }
    // Chrome already detached us (onDetach) — drop the session WITHOUT issuing a
    // redundant detach command.
    handleExternalDetach(tabId) {
      const session = this.sessions.get(tabId);
      if (!session) return;
      session.markDetached();
      this.sessions.delete(tabId);
    }
    // Whether a persistent session is currently held for this tab (no attach, no
    // side effect). Used by precise.ts to avoid a second, conflicting attach when
    // CDP mode already holds the tab.
    hasSession(tabId) {
      return this.sessions.has(tabId);
    }
    // For diagnostics / tests.
    get size() {
      return this.sessions.size;
    }
  };
  var cdpRegistry = new CdpSessionRegistry();
  var listenersInstalled = false;
  function installCdpLifecycleListeners() {
    if (listenersInstalled) return;
    listenersInstalled = true;
    chrome.tabs.onRemoved.addListener((tabId) => {
      void cdpRegistry.teardown(tabId);
    });
    chrome.debugger.onDetach.addListener((source) => {
      if (typeof source.tabId === "number") cdpRegistry.handleExternalDetach(source.tabId);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const change = changes.cdpMode;
      if (change && change.newValue === false) void cdpRegistry.teardownAll();
    });
  }

  // src/background/precise.ts
  var PRECISE_INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "checkbox",
    "radio",
    "textbox",
    "searchbox",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "combobox",
    "listbox",
    "option",
    "switch",
    "treeitem",
    "menuItem",
    "spinButton",
    "slider"
  ]);
  function axValue(v) {
    if (v && typeof v === "object" && "value" in v) return v.value;
    return v;
  }
  async function snapshotPrecise(maybeTabId, _args) {
    const tab = await resolveTargetTab(maybeTabId);
    await ensureAllowed(tab.url);
    if (!isDebuggable(tab.url)) {
      throw new Error(
        `page_snapshot_precise cannot debug this page (URL scheme not allowed): ${truncateUrl(tab.url)}`
      );
    }
    await injectIfNeeded(tab.id);
    const proceed = await chrome.tabs.sendMessage(tab.id, {
      op: "_info_toast",
      args: {
        message: "About to run a precise page scan \u2014 Chrome will show a 'Debugging' banner at the top that disappears automatically after the scan (about 1 second)."
      }
    }).catch(
      () => true
      /* content script missing → proceed anyway */
    );
    if (proceed === false || proceed && proceed.__cancelled) {
      return { cancelled: true };
    }
    if (proceed && proceed.__error) {
      console.warn("[bb] info toast failed:", proceed.__error);
    }
    const reusingAttach = cdpRegistry.hasSession(tab.id);
    if (!reusingAttach) {
      try {
        await dbgAttach(tab.id);
      } catch (e) {
        const msg = String(e.message || e);
        if (/another debugger/i.test(msg)) {
          throw new Error(
            "This tab has DevTools open, so page_snapshot_precise cannot attach. Please close DevTools and try again.",
            { cause: e }
          );
        }
        throw e;
      }
    }
    try {
      const tree = await dbgSend(tab.id, "Accessibility.getFullAXTree", {});
      const nodes = tree.nodes ?? [];
      const candidates = nodes.filter((n) => {
        if (n.ignored) return false;
        if (!n.backendDOMNodeId) return false;
        const role = axValue(n.role);
        if (!role) return false;
        if (!PRECISE_INTERACTIVE_ROLES.has(role)) return false;
        return true;
      });
      const out = [];
      let idx = 0;
      for (const n of candidates) {
        idx += 1;
        const ref = `p${idx}`;
        let descriptor;
        try {
          const resolved = await dbgSend(tab.id, "DOM.resolveNode", {
            backendNodeId: n.backendDOMNodeId
          });
          const objectId = resolved.object?.objectId;
          if (!objectId) continue;
          const callRes = await dbgSend(tab.id, "Runtime.callFunctionOn", {
            objectId,
            functionDeclaration: "function(ref) {  this.setAttribute('data-zcb-ref', ref);  var id = this.id ? '#' + this.id : '';  var tag = (this.tagName || '').toLowerCase();  return { tag: tag, id: id, name: this.getAttribute('name') || '',     value: (this.value !== undefined ? String(this.value).slice(0,60) : undefined) };}",
            arguments: [{ value: ref }],
            returnByValue: true
          });
          descriptor = callRes.result?.value ?? {};
        } catch (e) {
          console.warn("[bb] precise: skip node", ref, e.message);
          continue;
        }
        out.push({
          ref,
          role: axValue(n.role),
          name: truncateAx(axValue(n.name)),
          selector: descriptor.tag ? descriptor.tag + descriptor.id : void 0,
          value: descriptor.value
        });
      }
      return {
        refCount: out.length,
        nodes: out,
        url: tab.url,
        title: tab.title,
        precise: true
      };
    } finally {
      if (!reusingAttach) await dbgDetach(tab.id);
    }
  }
  function truncateUrl(u) {
    return (u || "").slice(0, 80);
  }
  function truncateAx(s) {
    if (typeof s !== "string") return s;
    return s.length > 120 ? s.slice(0, 120) + "\u2026" : s;
  }

  // src/shared/masking.ts
  var SENSITIVE_KEY = /(token|cookie|password|passwd|secret|api[_-]?key|auth|cred|session)/i;
  function maskPatterns(s) {
    let out = s;
    out = out.replace(/ey[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g, "\u2022\u2022\u2022\u2022[jwt]");
    out = out.replace(/\b[a-fA-F0-9]{32,}\b/g, "\u2022\u2022\u2022\u2022[hex]");
    out = out.replace(/\b\d{12,}\b/g, "\u2022\u2022\u2022\u2022[num]");
    out = out.replace(
      /(?:bearer|token|password|secret|api[_-]?key)\s*[:=]\s*\S+/gi,
      "\u2022\u2022\u2022\u2022[redacted]"
    );
    return out;
  }
  function maskString(s) {
    if (s.length < 8) return s;
    const out = maskPatterns(s);
    if (SENSITIVE_KEY.test(s) && s.length >= 8 && !/\s/.test(s)) {
      return "\u2022\u2022\u2022\u2022[sensitive]";
    }
    return out;
  }
  function maskCookieValue(v) {
    if (typeof v !== "string") return v;
    if (v.length < 8) return v;
    return maskPatterns(v);
  }
  function maskNumber(n) {
    if (Number.isInteger(n) && Math.abs(n) >= 1e11) return "\u2022\u2022\u2022\u2022[num]";
    return n;
  }
  function maskKeyName(key) {
    return SENSITIVE_KEY.test(key) ? "\u2022\u2022\u2022\u2022" + key.slice(-2) : key;
  }
  function maskSensitive(value) {
    if (value === null || value === void 0) return value;
    const t = typeof value;
    if (t === "string") return maskString(value);
    if (t === "number") return maskNumber(value);
    if (t === "boolean") return value;
    if (Array.isArray(value)) return value.map(maskSensitive);
    if (t === "object") {
      const out = {};
      for (const k of Object.keys(value)) {
        out[maskKeyName(k)] = maskSensitive(value[k]);
      }
      return out;
    }
    return value;
  }

  // src/background/cookies.ts
  async function cookieGet(maybeTabId, args) {
    let { url } = args || {};
    const { domain, name } = args || {};
    if (!url && !domain) {
      const tab = await resolveTargetTab(maybeTabId);
      await ensureAllowed(tab.url);
      url = tab.url;
    } else if (url) {
      await ensureAllowed(url);
    }
    if (domain) {
      await ensureDomainAllowed(domain);
    }
    const filter = {};
    if (url) filter.url = url;
    if (domain) filter.domain = domain;
    if (name) filter.name = name;
    const cookies = await chrome.cookies.getAll(filter);
    if (!cookies || cookies.length === 0) {
      return {
        cookies: [],
        count: 0,
        hint: "No cookies matched. If you expected some, verify the host is in the allowlist (popup \u2192 Allowed sites)."
      };
    }
    const out = cookies.map((c) => ({
      name: c.name,
      value: maskCookieValue(c.value),
      domain: c.domain,
      path: c.path,
      httpOnly: c.httpOnly,
      secure: c.secure,
      sameSite: c.sameSite,
      session: c.session,
      expirationDate: c.expirationDate
    }));
    return { cookies: out, count: out.length };
  }

  // src/background/backends/content-script.ts
  var ContentScriptBackend = class {
    async run(op, args, tab) {
      await ensureAllowed(tab.url);
      await injectIfNeeded(tab.id);
      const resp = await chrome.tabs.sendMessage(tab.id, {
        op,
        args,
        tabId: tab.id
      });
      if (resp && resp.__error) throw new Error(resp.__error);
      return resp;
    }
  };

  // src/content/util.ts
  function truncate(s, n) {
    return s.length > n ? s.slice(0, n) + "\u2026" : s;
  }

  // src/background/cdp/page-fns.ts
  var REF_ATTR = "data-zcb-ref";
  function pageSnapshot(refAttr) {
    function truncate2(s, n) {
      return s.length > n ? s.slice(0, n) + "\u2026" : s;
    }
    const INTERACTIVE_TAGS = /* @__PURE__ */ new Set([
      "a",
      "button",
      "input",
      "textarea",
      "select",
      "summary",
      "details",
      "label",
      "option",
      "optgroup"
    ]);
    const INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
      "button",
      "link",
      "checkbox",
      "radio",
      "textbox",
      "searchbox",
      "menuitem",
      "menuitemcheckbox",
      "menuitemradio",
      "tab",
      "combobox",
      "listbox",
      "option",
      "switch",
      "treeitem"
    ]);
    function isInteractive(el) {
      const tag = el.tagName.toLowerCase();
      if (tag === "iframe" || tag === "frame" || tag === "object" || tag === "embed") return false;
      if (INTERACTIVE_TAGS.has(tag)) return true;
      const role = el.getAttribute("role");
      if (role && INTERACTIVE_ROLES.has(role)) return true;
      if (el.hasAttribute("onclick")) return true;
      if (el.tabIndex >= 0) return true;
      return false;
    }
    function roleOf(el) {
      const explicit = el.getAttribute("role");
      if (explicit) return explicit;
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute("type") || "").toLowerCase();
      if (tag === "a" && el.hasAttribute("href")) return "link";
      if (tag === "button") return "button";
      if (tag === "input") {
        if (type === "checkbox") return "checkbox";
        if (type === "radio") return "radio";
        if (type === "submit" || type === "button" || type === "reset") return "button";
        return "textbox";
      }
      if (tag === "textarea") return "textbox";
      if (tag === "select") return "listbox";
      if (tag === "summary") return "button";
      return tag;
    }
    function nameOf(el) {
      const labelledBy = el.getAttribute("aria-labelledby");
      if (labelledBy) {
        const parts = labelledBy.split(/\s+/).map((id) => document.getElementById(id)).filter((n) => n !== null).map((n) => n.innerText || n.textContent || "").join(" ").trim();
        if (parts) return truncate2(parts, 120);
      }
      const aria = el.getAttribute("aria-label");
      if (aria && aria.trim()) return truncate2(aria.trim(), 120);
      const labelFor = el.id ? document.querySelector(`label[for="${el.id}"]`) : null;
      if (labelFor) {
        const t = (labelFor.innerText || "").trim();
        if (t) return truncate2(t, 120);
      }
      const wrapping = el.closest("label");
      if (wrapping && wrapping !== labelFor) {
        const t = (wrapping.innerText || "").trim();
        if (t) return truncate2(t, 120);
      }
      if (el.title && el.title.trim()) return truncate2(el.title.trim(), 120);
      const txt = (el.innerText || el.textContent || "").trim();
      if (txt) return truncate2(txt, 120);
      const placeholder = el.getAttribute("placeholder");
      if (placeholder) return truncate2(placeholder, 120);
      const alt = el.getAttribute("alt");
      if (alt) return truncate2(alt, 120);
      return "";
    }
    function previewValue(el) {
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT") {
        const field = el;
        const v = field.value || "";
        if (field.type === "password") return v ? "\u2022\u2022\u2022\u2022\u2022\u2022" : "";
        return truncate2(v, 60);
      }
      return void 0;
    }
    function isVisible(el) {
      if (!el || !el.getClientRects) return false;
      const rects = el.getClientRects();
      if (rects.length === 0) return false;
      const style = getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden") return false;
      if (parseFloat(style.opacity) === 0) return false;
      let cur = el;
      while (cur && cur.nodeType === 1) {
        if (cur.getAttribute("aria-hidden") === "true") return false;
        cur = cur.parentElement;
      }
      return true;
    }
    function cssSelectorOf(el) {
      const parts = [];
      let cur = el;
      while (cur && cur.nodeType === 1 && cur !== document.body) {
        let part = cur.tagName.toLowerCase();
        if (cur.id) {
          part += `#${cur.id}`;
          parts.unshift(part);
          break;
        }
        const parent = cur.parentElement;
        if (parent) {
          const tag = cur.tagName;
          const siblings = Array.from(parent.children).filter((c) => c.tagName === tag);
          if (siblings.length > 1) {
            const idx = siblings.indexOf(cur) + 1;
            part += `:nth-of-type(${idx})`;
          }
        }
        parts.unshift(part);
        cur = cur.parentElement;
      }
      return parts.join(" > ");
    }
    let refCounter = 0;
    function assignRef(el) {
      let ref = el.getAttribute(refAttr);
      if (ref) {
        const reused = parseInt(ref.slice(1), 10);
        if (!Number.isNaN(reused) && reused > refCounter) refCounter = reused;
      } else {
        refCounter += 1;
        ref = `e${refCounter}`;
        el.setAttribute(refAttr, ref);
      }
      return ref;
    }
    const out = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (el) => isInteractive(el) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
    });
    let node;
    while (node = walker.nextNode()) {
      const el = node;
      if (!isVisible(el)) continue;
      const ref = assignRef(el);
      out.push({
        ref,
        role: roleOf(el),
        name: nameOf(el),
        selector: cssSelectorOf(el),
        value: previewValue(el)
      });
    }
    return { refCount: out.length, nodes: out, url: location.href, title: document.title };
  }
  function pageText() {
    function truncate2(s, n) {
      return s.length > n ? s.slice(0, n) + "\u2026" : s;
    }
    const txt = (document.body?.innerText || "").replace(/\b\d{12,19}\b/g, "\u2022\u2022\u2022\u2022\u2022\u2022");
    return { text: truncate2(txt, 2e4), url: location.href };
  }
  function pageScroll(args) {
    if (typeof args.pixels === "number") {
      window.scrollBy(0, args.pixels);
    } else if (args.direction) {
      const dh = window.innerHeight * 0.9;
      switch (args.direction) {
        case "down":
          window.scrollBy(0, dh);
          break;
        case "up":
          window.scrollBy(0, -dh);
          break;
        case "top":
          window.scrollTo(0, 0);
          break;
        case "bottom":
          window.scrollTo(0, document.body.scrollHeight);
          break;
      }
    } else {
      throw new Error("scroll needs `direction` or `pixels`");
    }
    return { scrollY: window.scrollY, scrollX: window.scrollX };
  }
  function pageWaitFor(args) {
    const timeoutMs = args.timeoutMs ?? 3e4;
    const until = args.until === "domcontentloaded" ? "domcontentloaded" : "load";
    const start = Date.now();
    return new Promise((resolve, reject) => {
      let done = false;
      const navResult = () => ({
        matched: true,
        nav: true,
        url: location.href,
        readyState: document.readyState
      });
      const onReady = () => finish(resolve, navResult());
      const finish = (fn, value) => {
        if (done) return;
        done = true;
        window.removeEventListener("load", onReady, true);
        document.removeEventListener("DOMContentLoaded", onReady, true);
        fn(value);
      };
      if (args.nav) {
        if (until === "domcontentloaded") {
          if (document.readyState !== "loading") return finish(resolve, navResult());
          document.addEventListener("DOMContentLoaded", onReady, true);
        } else {
          if (document.readyState === "complete") return finish(resolve, navResult());
          window.addEventListener("load", onReady, true);
        }
      }
      const tick = () => {
        if (done) return;
        if (args.selector) {
          if (document.querySelector(args.selector)) {
            return finish(resolve, { matched: true, selector: args.selector });
          }
        }
        if (args.text) {
          if ((document.body?.innerText || "").includes(args.text)) {
            return finish(resolve, { matched: true, text: args.text });
          }
        }
        if (Date.now() - start > timeoutMs) {
          return finish(reject, new Error(`wait_for timed out after ${timeoutMs}ms`));
        }
        setTimeout(tick, 150);
      };
      tick();
    });
  }
  function readStorage(args) {
    const type = args.type === "session" ? "session" : "local";
    const key = args.key;
    let store;
    try {
      store = type === "session" ? window.sessionStorage : window.localStorage;
    } catch (e) {
      throw new Error(`storage unavailable: ${e instanceof Error ? e.message : String(e)}`, {
        cause: e
      });
    }
    if (key !== void 0 && key !== null && key !== "") {
      const raw = store.getItem(key);
      if (raw === null) return { key, found: false };
      return { key, found: true, value: raw };
    }
    const entries = {};
    let count = 0;
    const MAX = 500;
    for (let i = 0; i < store.length && count < MAX; i++) {
      const k = store.key(i);
      if (k === null) continue;
      try {
        entries[k] = store.getItem(k) || "";
      } catch {
        entries[k] = "[unreadable]";
      }
      count++;
    }
    const truncated = store.length > MAX;
    return { type, entries, count, truncated, totalKeys: store.length };
  }
  function doClick(refAttr, args) {
    function resolveTarget() {
      if (args.ref) {
        const el2 = document.querySelector(`[${refAttr}="${args.ref}"]`);
        if (!el2) throw new Error(`ref not found: ${args.ref} \u2014 call page_snapshot again`);
        return el2;
      }
      if (args.selector) {
        const el2 = document.querySelector(args.selector);
        if (!el2) throw new Error(`selector matched nothing: ${args.selector}`);
        return el2;
      }
      throw new Error("click/fill needs `ref` or `selector`");
    }
    function roleOf(el2) {
      const explicit = el2.getAttribute("role");
      if (explicit) return explicit;
      const tag = el2.tagName.toLowerCase();
      const type = (el2.getAttribute("type") || "").toLowerCase();
      if (tag === "a" && el2.hasAttribute("href")) return "link";
      if (tag === "button") return "button";
      if (tag === "input") {
        if (type === "checkbox") return "checkbox";
        if (type === "radio") return "radio";
        if (type === "submit" || type === "button" || type === "reset") return "button";
        return "textbox";
      }
      if (tag === "textarea") return "textbox";
      if (tag === "select") return "listbox";
      if (tag === "summary") return "button";
      return tag;
    }
    const el = resolveTarget();
    el.scrollIntoView({ block: "center" });
    el.focus?.();
    el.click();
    return { clicked: args.ref || args.selector, role: roleOf(el) };
  }
  function doFill(refAttr, args) {
    function resolveTarget() {
      if (args.ref) {
        const el2 = document.querySelector(`[${refAttr}="${args.ref}"]`);
        if (!el2) throw new Error(`ref not found: ${args.ref} \u2014 call page_snapshot again`);
        return el2;
      }
      if (args.selector) {
        const el2 = document.querySelector(args.selector);
        if (!el2) throw new Error(`selector matched nothing: ${args.selector}`);
        return el2;
      }
      throw new Error("click/fill needs `ref` or `selector`");
    }
    const el = resolveTarget();
    const value = args.value ?? "";
    el.focus?.();
    const field = el;
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) {
      setter.call(el, value);
    } else {
      field.value = value;
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return { filled: args.ref || args.selector };
  }

  // src/background/backends/cdp.ts
  var CdpBackend = class {
    async run(op, args, tab) {
      await ensureAllowed(tab.url);
      if (!isDebuggable(tab.url)) {
        throw new Error(
          `CDP mode cannot control this page (URL scheme not allowed): ${(tab.url || "").slice(0, 80)}`
        );
      }
      const session = await cdpRegistry.get(tab.id);
      switch (op) {
        case "page_snapshot":
          return await session.evaluate(pageSnapshot, [REF_ATTR]);
        case "page_text":
          return await session.evaluate(pageText, []);
        case "page_scroll":
          return await session.evaluate(pageScroll, [
            { direction: args.direction, pixels: args.pixels }
          ]);
        case "page_wait_for":
          try {
            return await session.evaluate(
              pageWaitFor,
              [
                {
                  nav: args.nav,
                  selector: args.selector,
                  text: args.text,
                  timeoutMs: args.timeoutMs,
                  until: args.until
                }
              ],
              { awaitPromise: true }
            );
          } catch (e) {
            const msg = String(e?.message || e);
            if (args.nav && /context was destroyed|Cannot find context|Execution context/i.test(msg)) {
              return { matched: true, nav: true };
            }
            throw e;
          }
        case "page_screenshot":
          return await session.screenshot();
        case "storage_get":
          return await this.storageGet(session, args);
        case "page_fill":
          return await session.evaluate(doFill, [
            REF_ATTR,
            { ref: args.ref, selector: args.selector, value: args.value }
          ]);
        case "page_click":
          return await this.click(session, args);
        case "page_eval":
          return await this.pageEval(session, args);
        default:
          throw new Error(`CDP backend: unsupported op ${op}`);
      }
    }
    // storage_get: read raw values in the page, mask in the SW (always-on).
    async storageGet(session, args) {
      const raw = await session.evaluate(readStorage, [{ type: args.type, key: args.key }]);
      if ("entries" in raw) {
        const masked = {};
        for (const k of Object.keys(raw.entries)) masked[k] = maskString(raw.entries[k]);
        return { ...raw, entries: masked };
      }
      if (raw.found) return { ...raw, value: maskString(raw.value) };
      return raw;
    }
    // page_click runs directly; the per-site allowlist (checked in run()) is the
    // gate.
    async click(session, args) {
      return await session.evaluate(doClick, [REF_ATTR, { ref: args.ref, selector: args.selector }]);
    }
    // page_eval: run in the MAIN world (gated by the per-tool disable + allowlist;
    // the page_eval-specific toggle and per-call confirmation were removed).
    async pageEval(session, args) {
      const code = args.code;
      if (typeof code !== "string" || !code.trim()) {
        throw new Error("page_eval needs non-empty `code`");
      }
      const expression = `(async () => {
${code}
})()`;
      const res = await session.rawEvaluate(expression, { awaitPromise: true });
      if (res.exceptionDetails) {
        const ex = res.exceptionDetails.exception;
        const description = ex?.description || res.exceptionDetails.text || "Error";
        return {
          __evalError: true,
          name: ex?.className || "Error",
          message: description.split("\n")[0],
          stack: truncate(description, 2e3)
        };
      }
      return maskSensitive(res.result?.value);
    }
  };

  // src/background/page-backend.ts
  var contentScriptBackend = new ContentScriptBackend();
  var cdpBackend = new CdpBackend();
  function selectBackend(cdpMode) {
    return cdpMode ? cdpBackend : contentScriptBackend;
  }

  // src/background/dispatch.ts
  function assertNotDisabled(op, disabledTools) {
    if (!op || !(op in TOOL_META)) return;
    const decision = decide(op, { disabledTools });
    if (!decision.allowed && decision.reason === "tool disabled in settings") {
      throw new Error(`${decision.reason}: ${op}`);
    }
  }
  async function dispatch(req) {
    const { op } = req;
    const disabled = await getSetting("disabledTools");
    assertNotDisabled(op, Array.isArray(disabled) ? disabled : []);
    switch (req.op) {
      case "tab_list":
        return await tabList();
      case "tab_focus":
        return await tabFocus(req.args.tabId);
      case "tab_open":
        return await tabOpen(req.args.url);
      case "tab_close":
        return await tabClose(req.args.tabId);
      case "page_snapshot_precise":
        return await snapshotPrecise(req.tabId, req.args);
      case "cookie_get":
        return await cookieGet(req.tabId, req.args);
    }
    const tab = await resolveTargetTab(req.tabId);
    const cdpMode = await getSetting("cdpMode") === true;
    const backend = selectBackend(cdpMode);
    return await backend.run(op, req.args, tab);
  }

  // src/background/port.ts
  var NATIVE_HOST = "com.browser_bridge.host";
  var port = null;
  var portOk = false;
  var reconnectTimer = null;
  function isNativeConnected() {
    return portOk;
  }
  function connectNative() {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    try {
      port = chrome.runtime.connectNative(NATIVE_HOST);
      portOk = true;
      console.log("[bb] native host connected");
      port.onMessage.addListener(onNativeMessage);
      port.onDisconnect.addListener(onNativeDisconnect);
    } catch (e) {
      portOk = false;
      console.error("[bb] connectNative threw", e);
      scheduleReconnect();
    }
  }
  function onNativeDisconnect(_p) {
    portOk = false;
    port = null;
    const err = chrome.runtime.lastError;
    console.warn("[bb] native host disconnected:", err?.message || "unknown");
    scheduleReconnect();
  }
  function scheduleReconnect() {
    if (reconnectTimer) return;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connectNative();
    }, 2e3);
  }
  function onNativeMessage(msg) {
    if (!msg || typeof msg.id === "undefined" || !msg.op) {
      console.warn("[bb] malformed BridgeReq", msg);
      return;
    }
    dispatch(msg).then(
      (data) => sendResponse(msg.id, true, data),
      (err) => sendResponse(msg.id, false, void 0, String(err?.message || err || "error"))
    );
  }
  function sendResponse(id, ok, data, error) {
    if (!port) return;
    try {
      port.postMessage({ id, ok, data, error: ok ? void 0 : error });
    } catch (e) {
      console.warn("[bb] postMessage failed", e);
    }
  }

  // src/background/messages.ts
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse2) => {
    if (msg?.type === "resolve_allow") {
      resolvePendingAllow(msg.id, msg.allow).then((r) => sendResponse2(r));
      return true;
    }
    if (msg?.type === "get_allowlist") {
      getAllowlist().then((list) => sendResponse2({ list }));
      return true;
    }
    if (msg?.type === "add_allow") {
      const glob = msg.glob;
      if (typeof glob !== "string" || !glob) {
        sendResponse2({ ok: false, error: "missing glob" });
        return false;
      }
      addAllow(glob).then((list) => sendResponse2({ ok: true, list }));
      return true;
    }
    if (msg?.type === "remove_allow") {
      removeAllow(msg.glob).then((r) => sendResponse2({ ok: true, ...r }));
      return true;
    }
    if (msg?.type === "get_status") {
      sendResponse2({ nativeConnected: isNativeConnected() });
      return false;
    }
    if (msg?.type === "capture_visible_tab") {
      chrome.tabs.captureVisibleTab({ format: "png" }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse2({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse2({ dataUrl });
        }
      });
      return true;
    }
  });

  // src/shared/extension-id.ts
  var PINNED_EXTENSION_ID = "mkjjlmjbcljpcfkfadfmhblmmddkdihf";
  var STORE_EXTENSION_ID = "dgccjfjjilfpkbdllclmkiicajndkfcd";
  var TRUSTED_EXTENSION_IDS = [PINNED_EXTENSION_ID, STORE_EXTENSION_ID];
  function diagnoseExtensionId(runtimeId, expected = TRUSTED_EXTENSION_IDS) {
    if (expected.includes(runtimeId)) {
      return {
        ok: true,
        level: "ok",
        message: `extension id ${runtimeId} is trusted \u2014 native messaging will be accepted`
      };
    }
    return {
      ok: false,
      level: "error",
      message: `extension id mismatch: running=${runtimeId} trusted=${expected.join(", ")}. The native-messaging host pins the trusted ids in allowed_origins, so this extension will be REJECTED and browser-bridge cannot connect. Likely cause: you loaded a build whose manifest lacks the pinned \`key\` (Chrome then derives a path-based id), or an install whose host manifest predates this build's id. Fix: load the built extension/dist that contains the pinned key (or install from the Chrome Web Store), and re-run the installer so allowed_origins trusts your id.`
    };
  }

  // src/background/id-check.ts
  function verifyExtensionId() {
    const d = diagnoseExtensionId(chrome.runtime.id);
    if (d.ok) {
      console.log("[bb]", d.message);
    } else {
      console.error("[bb] \u26A0", d.message);
    }
  }

  // src/background.ts
  verifyExtensionId();
  installCdpLifecycleListeners();
  chrome.runtime.onStartup.addListener(connectNative);
  chrome.runtime.onInstalled.addListener(connectNative);
  connectNative();
})();
